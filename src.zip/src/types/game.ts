
export type Difficulty = 'easy' | 'medium' | 'hard';

export interface FinancialTerm {
  id: string;
  term: string;
  hint: string;
  question?: string;
}

export interface GameLevel {
  id: number;
  story?: string;
  question?: string;
  financialTerms: FinancialTerm[];
}

export interface GameData {
  easy: GameLevel[];
  medium: GameLevel[];
  hard: GameLevel[];
  short?: GameLevel[];
}

export interface GameStats {
  score: number;
  currentLevelScore: number;
  easyCompleted: boolean;
  mediumCompleted: boolean;
  hardCompleted: boolean;
  currentLevel: number;
  foundTerms: string[];
  allSubmittedWords: string[];
  currentStory?: GameLevel;
  hintsUsed: number;
  startGame: (difficulty: Difficulty) => void;
  difficulty?: Difficulty;
  levelScores: {
    easy: number;
    medium: number;
    hard: number;
  };
}
