import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { useToast } from '@/hooks/use-toast';
import { Difficulty, GameStats } from '@/types/game';
import gameData from '@/data/gameData';
import { clearUserTerms, getUserId } from '@/data/userTerms';

interface GameContextType {
  difficulty: Difficulty | null;
  gameStats: GameStats;
  currentLevelIndex: number;
  timer: number;
  isGameActive: boolean;
  timerColor: string;
  shownStoryIds: Record<Difficulty, number[]>;
  
  setDifficulty: (difficulty: Difficulty) => void;
  startGame: (difficulty: Difficulty) => void;
  resetGame: () => void;
  checkAnswer: (answer: string) => boolean;
  getCurrentLevelData: () => any;
  showHint: () => void;
  updateScore: (points: number) => void;
  completeLevel: () => void;
  nextLevel: () => void;
  prevLevel: () => void;
  goToHome: () => void;
  clearShownStoryIds: (difficulty: Difficulty) => void;
  resetMediumTerms: () => void; // New function to reset medium terms for a user
}

const initialGameStats: GameStats = {
  score: 0,
  currentLevelScore: 0,
  easyCompleted: false,
  mediumCompleted: false,
  hardCompleted: false,
  currentLevel: 1,
  foundTerms: [],
  allSubmittedWords: [],
  hintsUsed: 0,
  startGame: () => {},
  levelScores: {
    easy: 0,
    medium: 0,
    hard: 0
  }
};

// Load previously shown story IDs from localStorage or initialize empty arrays
const loadShownStoryIds = (): Record<Difficulty, number[]> => {
  try {
    const savedData = localStorage.getItem('shownStoryIds');
    if (savedData) {
      return JSON.parse(savedData);
    }
  } catch (error) {
    console.error('Error loading shown story IDs:', error);
  }
  return {
    easy: [],
    medium: [],
    hard: []
  };
};

const GameContext = createContext<GameContextType | undefined>(undefined);

// Load game state from localStorage
// Add this near the top of the file after other imports
const LAST_USER_ID_KEY = 'lastUserId';

// Modify the loadGameState function
const loadGameState = () => {
  try {
    const savedState = localStorage.getItem('gameState');
    const currentUserId = getUserId();
    const lastUserId = localStorage.getItem(LAST_USER_ID_KEY);

    // Clear state if user ID changed
    if (currentUserId !== lastUserId) {
      localStorage.removeItem('gameState');
      localStorage.setItem(LAST_USER_ID_KEY, currentUserId);
      return null;
    }

    if (savedState) {
      return JSON.parse(savedState);
    }
  } catch (error) {
    console.error('Error loading game state:', error);
  }
  return null;
};

// Save game state to localStorage
const saveGameState = (state: any) => {
  try {
    localStorage.setItem('gameState', JSON.stringify(state));
  } catch (error) {
    console.error('Error saving game state:', error);
  }
};

export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Initialize state from localStorage or defaults
  const savedState = loadGameState();
  const [difficulty, setDifficulty] = useState<Difficulty | null>(savedState?.difficulty || null);
  const [gameStats, setGameStats] = useState<GameStats>(savedState?.gameStats || initialGameStats);
  const [currentLevelIndex, setCurrentLevelIndex] = useState<number>(savedState?.currentLevelIndex || 0);
  const [timer, setTimer] = useState<number>(savedState?.timer || 60);
  const [isGameActive, setIsGameActive] = useState<boolean>(savedState?.isGameActive || false);
  const [timerInterval, setTimerInterval] = useState<NodeJS.Timeout | null>(null);
  const [shownStoryIds, setShownStoryIds] = useState<Record<Difficulty, number[]>>(loadShownStoryIds());

  // Add beforeunload event listener to prevent accidental page reloads
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (isGameActive) {
        e.preventDefault();
        e.returnValue = '';
        return '';
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [isGameActive]);

  // Save game state whenever it changes
  useEffect(() => {
    if (isGameActive) {
      saveGameState({
        difficulty,
        gameStats,
        currentLevelIndex,
        timer,
        isGameActive
      });
    }
  }, [difficulty, gameStats, currentLevelIndex, timer, isGameActive]);

  const getTimerColor = () => {
    if (timer > 40) return 'bg-game-timer-green';
    if (timer > 20) return 'bg-game-timer-yellow';
    return 'bg-game-timer-red';
  };
  
  const timerColor = getTimerColor();

  // Helper function to get random story indices for a difficulty level
  const getRandomStoryIndices = (difficulty: Difficulty): number[] => {
    const totalStories = gameData[difficulty].length;
    const levelCount = 5; // Number of levels to play
    
    // Create array of all available story indices
    const allIndices = Array.from({ length: totalStories }, (_, i) => i);
    
    // Get previously shown story IDs for this difficulty
    const previouslyShown = shownStoryIds[difficulty] || [];
    
    // Filter out indices that have been shown before
    const unusedIndices = allIndices.filter(index => 
      !previouslyShown.includes(gameData[difficulty][index].id)
    );
    
    // If we have enough unused stories, use them
    if (unusedIndices.length >= levelCount) {
      // Shuffle unused indices
      for (let i = unusedIndices.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [unusedIndices[i], unusedIndices[j]] = [unusedIndices[j], unusedIndices[i]];
      }
      return unusedIndices.slice(0, levelCount);
    }
    
    // If we don't have enough unused stories, reset the shown stories and start fresh
    clearShownStoryIds(difficulty);
    
    // Shuffle all indices
    const shuffledIndices = [...allIndices];
    for (let i = shuffledIndices.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffledIndices[i], shuffledIndices[j]] = [shuffledIndices[j], shuffledIndices[i]];
    }
    
    return shuffledIndices.slice(0, levelCount);
  };

  // Function to save shown story IDs to localStorage
  const saveShownStoryIds = (newShownIds: Record<Difficulty, number[]>) => {
    try {
      localStorage.setItem('shownStoryIds', JSON.stringify(newShownIds));
    } catch (error) {
      console.error('Error saving shown story IDs:', error);
    }
  };
  
  // Function to clear shown story IDs for a specific difficulty
  const clearShownStoryIds = (difficulty: Difficulty) => {
    try {
      const currentShownIds = {...shownStoryIds};
      currentShownIds[difficulty] = [];
      setShownStoryIds(currentShownIds);
      saveShownStoryIds(currentShownIds);
      console.log(`Cleared shown story IDs for ${difficulty} level`);
    } catch (error) {
      console.error('Error clearing shown story IDs:', error);
    }
  };

  const startGame = (selectedDifficulty: Difficulty) => {
    // Get random story indices for the selected difficulty
    const randomIndices = getRandomStoryIndices(selectedDifficulty);
    
    // Create a custom game data object with only the selected stories
    const selectedStoryIds = randomIndices.map(index => gameData[selectedDifficulty][index].id);
    
    // Update shown stories for the selected difficulty
    const newShownStoryIds = {
      ...shownStoryIds,
      [selectedDifficulty]: [...(shownStoryIds[selectedDifficulty] || []), ...selectedStoryIds]
    };
    setShownStoryIds(newShownStoryIds);
    saveShownStoryIds(newShownStoryIds);

    setDifficulty(selectedDifficulty);
    setCurrentLevelIndex(0);
    setGameStats({
      ...initialGameStats,
      easyCompleted: gameStats.easyCompleted,
      mediumCompleted: gameStats.mediumCompleted,
      hardCompleted: gameStats.hardCompleted,
      currentLevel: 1,
      foundTerms: [],
      allSubmittedWords: []
    });
    
    navigate(`/game/${selectedDifficulty}`);
    
    setIsGameActive(true);
    setTimer(60);
    
    if (timerInterval) clearInterval(timerInterval);
    const interval = setInterval(() => {
      setTimer(prevTimer => {
        if (prevTimer <= 1) {
          clearInterval(interval);
          setIsGameActive(false);
          if (window.location.pathname.includes('/game')) {
            toast({
              title: "Time's up!",
              variant: "destructive"
            });
          }
          navigate('/');
          return 0;
        }
        return prevTimer - 1;
      });
    }, 1000);
    
    setTimerInterval(interval);
  };

  const resetGame = () => {
    setGameStats(initialGameStats);
    setDifficulty(null);
    setCurrentLevelIndex(0);
    setTimer(60);
    setIsGameActive(false);
    if (timerInterval) clearInterval(timerInterval);
    // Keep shown story IDs to maintain story history across game sessions
    
    // Option to reset user-specific medium terms
    // Uncomment this line to reset terms when game is reset
    // clearUserTerms();
    // They will be used to prioritize unshown stories in the next game
  };

  const getCurrentLevelData = () => {
    if (!difficulty) return null;
    return gameData[difficulty][currentLevelIndex];
  };

  const checkAnswer = (answer: string): boolean => {
    if (!difficulty || !isGameActive) return false;
    
    const currentLevel = getCurrentLevelData();
    if (!currentLevel) return false;

    const lowerCaseAnswer = answer.toLowerCase();

    // Check if the word has already been found in the current level
    if (gameStats.foundTerms.includes(lowerCaseAnswer)) {
      toast({
        title: "Already Found",
        description: "You've already found this term!",
        variant: "default"
      });
      return false;
    }
    
    // Check if the word has been submitted in any previous level
    if (gameStats.allSubmittedWords.includes(lowerCaseAnswer)) {
      toast({
        title: "Already Used",
        description: "You've already used this word in a previous level!",
        variant: "default"
      });
      return false;
    }

    // Trim whitespace and convert to lowercase for comparison
    const normalizedAnswer = answer.toLowerCase().trim();
    
    const isCorrect = currentLevel.financialTerms.some((term) => {
      const termLower = term.term.toLowerCase().trim();
      
      // Check for exact match
      if (termLower === normalizedAnswer) return true;
      
      // Check if the answer is part of a compound term
      if (termLower.includes(normalizedAnswer)) {
        const words = termLower.split(' ');
        // Only match if it's a complete word within the term
        return words.includes(normalizedAnswer);
      }
      
      return false;
    });
    
    // Debug log to help identify issues with term matching
    console.log('Checking answer:', normalizedAnswer);
    console.log('Available terms:', currentLevel.financialTerms.map(term => term.term.toLowerCase().trim()));
    console.log('Is correct:', isCorrect);

    if (isCorrect) {
      const totalTerms = currentLevel.financialTerms.length;
      const foundTermsCount = gameStats.foundTerms.length + 1; // Including current term
      const completionPercentage = (foundTermsCount / totalTerms) * 100;
      
      // Calculate points based on difficulty
      // For easy level, award 1 point per term found
      // For medium and hard levels, points are proportional to completion
      const points = difficulty === 'easy' ? 1 : 
        difficulty === 'medium' ? Math.round((2 * foundTermsCount) / totalTerms) : 
        Math.round((3 * foundTermsCount) / totalTerms);
      
      setGameStats(prev => {
        const newLevelScore = prev.levelScores[difficulty] + points;
        return {
          ...prev,
          foundTerms: [...prev.foundTerms, lowerCaseAnswer],
          allSubmittedWords: [...prev.allSubmittedWords, lowerCaseAnswer],
          score: prev.hardCompleted ? prev.score : newLevelScore,
          currentLevelScore: newLevelScore,
          levelScores: {
            ...prev.levelScores,
            [difficulty]: newLevelScore
          }
        };
      });
      
      // Show completion percentage in toast
      // In the checkAnswer function, remove or comment out these toast notifications:
      
      // Remove or comment out these lines
      /*
      toast({
        title: "Correct!",
        description: `You found the term: ${answer}\nLevel Progress: ${completionPercentage.toFixed(1)}%`,
        variant: "default",
        duration: 3000 // 3 seconds duration
      });
      
      toast({
        title: "Correct!",
        description: `You found the term: ${answer}`,
        variant: "default"
      });
      */
      
      if (gameStats.foundTerms.length + 1 >= currentLevel.financialTerms.length) {
        if (timerInterval) clearInterval(timerInterval);
        setIsGameActive(false);
        
        if (currentLevelIndex >= gameData[difficulty].length - 1) {
          if (difficulty === 'easy') {
            setGameStats(prev => ({ ...prev, easyCompleted: true }));
          } else if (difficulty === 'medium') {
            setGameStats(prev => ({ ...prev, mediumCompleted: true }));
          } else if (difficulty === 'hard') {
            setGameStats(prev => ({ ...prev, hardCompleted: true }));
            navigate('/score');
            return true;
          }
          
          toast({
            title: "Level Completed!",
            description: `You've completed all ${difficulty} levels!`,
            variant: "default"
          });
          
          navigate('/');
        } else {
          toast({
            title: "Level Completed!",
            description: "All terms found! Moving to next level.",
            variant: "default"
          });
          
          setCurrentLevelIndex(prev => prev + 1);
          setGameStats(prev => ({
            ...prev,
            currentLevel: prev.currentLevel + 1,
            foundTerms: []
          }));
          
          setTimer(60);
          setIsGameActive(true);
          
          if (timerInterval) clearInterval(timerInterval);
          const interval = setInterval(() => {
            setTimer(prevTimer => {
              if (prevTimer <= 1) {
                clearInterval(interval);
                setIsGameActive(false);
                if (window.location.pathname.includes('/game')) {
                  toast({
                    title: "Time's up!",
                    variant: "destructive",
                    duration: 3000 // 3 seconds duration
                  });
                }
                navigate('/');
                return 0;
              }
              return prevTimer - 1;
            });
          }, 1000);
          
          setTimerInterval(interval);
        }
      }
      
      return true;
    } else {
      // Show error message without affecting game state
      if (window.location.pathname.includes('/game')) {
        toast({
          title: "Incorrect",
          description: "That's not a financial term from this story.",
          variant: "destructive"
        });
      }
      return false;
      
      return false;
    }
  };

  const showHint = () => {
    if (!difficulty || !isGameActive) return;
    
    const currentLevel = getCurrentLevelData();
    if (!currentLevel) return;
    
    const unFoundTerms = currentLevel.financialTerms.filter(
      term => !gameStats.foundTerms.includes(term.term.toLowerCase())
    );
    
    if (unFoundTerms.length === 0) {
      toast({
        title: "No Hints Available",
        description: "You've found all the terms!",
        variant: "default"
      });
      return;
    }
    
    const randomTerm = unFoundTerms[Math.floor(Math.random() * unFoundTerms.length)];
    
    toast({
      title: "Hint",
      description: randomTerm.hint,
      variant: "default"
    });
    
    setGameStats(prev => ({
      ...prev,
      score: Math.max(0, prev.score - 1)
    }));
  };

  const updateScore = (points: number) => {
    setGameStats(prev => ({
      ...prev,
      score: prev.score + points
    }));
  };

  const completeLevel = () => {
    if (!difficulty) return;
    
    if (timerInterval) clearInterval(timerInterval);
    setIsGameActive(false);
    
    if (currentLevelIndex < gameData[difficulty].length - 1) {
      setCurrentLevelIndex(prev => prev + 1);
      setGameStats(prev => ({
        ...prev,
        currentLevel: prev.currentLevel + 1,
        foundTerms: []
      }));
      
      setTimer(60);
      setIsGameActive(true);
      
      const interval = setInterval(() => {
        setTimer(prevTimer => {
          if (prevTimer <= 1) {
            clearInterval(interval);
            setIsGameActive(false);
            navigate('/');
            return 0;
          }
          return prevTimer - 1;
        });
      }, 1000);
      
      setTimerInterval(interval);
    } else {
      if (difficulty === 'easy') {
        setGameStats(prev => ({ ...prev, easyCompleted: true }));
      } else if (difficulty === 'medium') {
        setGameStats(prev => ({ ...prev, mediumCompleted: true }));
      } else if (difficulty === 'hard') {
        setGameStats(prev => ({ ...prev, hardCompleted: true }));
        navigate('/score');
        return;
      }
      
      navigate('/');
    }
  };

  const nextLevel = () => {
    const currentLevel = getCurrentLevelData();
    if (!currentLevel) return;
    
    if (!difficulty) return;
    
    if (currentLevelIndex < gameData[difficulty].length - 1) {
      // Check for level restrictions
      if (difficulty === 'medium' && !gameStats.easyCompleted) {
        toast({
          title: "Level Locked",
          description: "You need to complete the Easy level first!",
          variant: "destructive"
        });
        return;
      }

      if (difficulty === 'hard' && !gameStats.mediumCompleted) {
        toast({
          title: "Level Locked",
          description: "You need to complete the Medium level first!",
          variant: "destructive"
        });
        return;
      }
      
      if (timerInterval) clearInterval(timerInterval);

      // Check for minimum term requirement in all levels
      const foundTermsCount = gameStats.foundTerms.length;
      const totalTerms = currentLevel.financialTerms.length;
      const completionPercentage = (foundTermsCount / totalTerms) * 100;
      
      if (foundTermsCount === 0) {
        toast({
          title: "Cannot Progress",
          description: "You need to find at least one term before moving to the next level.",
          variant: "destructive"
        });
        // Continue running timer without returning
        setIsGameActive(true);
        const interval = setInterval(() => {
          setTimer(prevTimer => {
            if (prevTimer <= 1) {
              clearInterval(interval);
              setIsGameActive(false);
              if (window.location.pathname.includes('/game')) {
                toast({
                  title: "Time's up!",
                  variant: "destructive",
                  duration: 3000 // 3 seconds duration
                });
              }
              navigate('/');
              return 0;
            }
            return prevTimer - 1;
          });
        }, 1000);
        setTimerInterval(interval);
        return;
      }

      toast({
        title: "Level Progress",
        description: `You completed ${completionPercentage.toFixed(1)}% of this level (${foundTermsCount} out of ${totalTerms} terms found)`,
        variant: "default"
      });
      
      setCurrentLevelIndex(prev => prev + 1);
      setGameStats(prev => ({
        ...prev,
        currentLevel: prev.currentLevel + 1,
        foundTerms: []
      }));
      
      setTimer(60);
      setIsGameActive(true);
      
      const interval = setInterval(() => {
        setTimer(prevTimer => {
          if (prevTimer <= 1) {
            clearInterval(interval);
            setIsGameActive(false);
            if (window.location.pathname.includes('/game')) {
              toast({
                title: "Time's up!",
                variant: "destructive",
                duration: 3000,
                className: "absolute top-4 right-4"
              });
            }
            navigate('/');
            return 0;
          }
          return prevTimer - 1;
        });
      }, 1000);
      
      setTimerInterval(interval);
    }
  };

  const prevLevel = () => {
    if (!difficulty) return;
    
    if (currentLevelIndex > 0) {
      if (timerInterval) clearInterval(timerInterval);
      
      setCurrentLevelIndex(prev => prev - 1);
      setGameStats(prev => ({
        ...prev,
        currentLevel: prev.currentLevel - 1,
        foundTerms: []
      }));
      
      setTimer(60);
      setIsGameActive(true);
      
      const interval = setInterval(() => {
        setTimer(prevTimer => {
          if (prevTimer <= 1) {
            clearInterval(interval);
            setIsGameActive(false);
            if (window.location.pathname.includes('/game')) {
              toast({
                title: "Time's up!",
                variant: "destructive",
                duration: 3000,
                className: "absolute top-4 right-4 bg-red-100 border-red-400 text-red-700"
              });
            }
            navigate('/');
            return 0;
          }
          return prevTimer - 1;
        });
      }, 1000);
      
      setTimerInterval(interval);
    }
  };

  const goToHome = () => {
    if (timerInterval) clearInterval(timerInterval);
    setIsGameActive(false);
    setGameStats({
      ...initialGameStats,
      easyCompleted: gameStats.easyCompleted,
      mediumCompleted: gameStats.mediumCompleted,
      hardCompleted: gameStats.hardCompleted
    });
    setDifficulty(null);
    setCurrentLevelIndex(0);
    // Clear shown story IDs for all difficulties when going home
    const clearedShownIds = {
      easy: [],
      medium: [],
      hard: []
    };
    setShownStoryIds(clearedShownIds);
    saveShownStoryIds(clearedShownIds);
    navigate('/');
  };

  // Function to reset medium terms for a user
  const resetMediumTerms = () => {
    clearUserTerms();
    toast({
      title: "Terms Reset",
      description: "You'll now get a new set of financial terms for the medium level.",
      variant: "default"
    });
  };

  useEffect(() => {
    return () => {
      if (timerInterval) clearInterval(timerInterval);
    };
  }, [timerInterval]);

  useEffect(() => {
    if (timer === 0 && isGameActive) {
      setIsGameActive(false);
      if (window.location.pathname.includes('/game')) {
        toast({
          title: "Time's up!",
          description: "You ran out of time for this level.",
          variant: "destructive"
        });
      }
      navigate('/');
    }
  }, [timer, isGameActive, navigate, toast]);

  return (
    <GameContext.Provider
      value={{
        difficulty,
        gameStats,
        currentLevelIndex,
        timer,
        isGameActive,
        timerColor,
        shownStoryIds,
        setDifficulty,
        startGame,
        resetGame,
        checkAnswer,
        getCurrentLevelData,
        showHint,
        updateScore,
        completeLevel,
        nextLevel,
        prevLevel,
        goToHome,
        clearShownStoryIds,
        resetMediumTerms
      }}
    >
      {children}
    </GameContext.Provider>
  );
};

export const useGame = (): GameContextType => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

// Custom notification function
  const showCustomNotification = (message: string, term: string) => {
    const toastArea = document.getElementById('custom-toast-area');
    if (toastArea) {
      const notification = document.createElement('div');
      notification.className = 'bg-white rounded-md shadow-md p-3 mb-2 animate-in fade-in';
      notification.innerHTML = `
        <div class="font-medium">Correct!</div>
        <div class="text-sm">You found the term: ${term}</div>
      `;
      toastArea.appendChild(notification);
      
      // Remove after 3 seconds
      setTimeout(() => {
        notification.classList.add('animate-out', 'fade-out');
        setTimeout(() => {
          if (toastArea.contains(notification)) {
            toastArea.removeChild(notification);
          }
        }, 300);
      }, 3000);
    }
  };
