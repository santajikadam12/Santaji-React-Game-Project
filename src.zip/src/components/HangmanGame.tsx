import React, { useState, useEffect } from 'react';
import { useGame } from '@/context/GameContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowRight, LightbulbIcon } from 'lucide-react';
import TimerBar from './TimerBar';
import { FinancialTerm } from '@/types/game';
import { getUserHardTerms } from '@/data/userHardTerms';

const HangmanGame: React.FC = () => {
  const {
    getCurrentLevelData,
    showHint,
    updateScore,
    gameStats,
    difficulty,
    nextLevel
  } = useGame();

  // Get random terms for hard level
  const [hardTerms, setHardTerms] = useState<FinancialTerm[]>([]);
  
  useEffect(() => {
    if (difficulty === 'hard') {
      // Get 5 random terms for hard level
      const terms = getUserHardTerms(5);
      setHardTerms(terms);
    }
  }, [difficulty]);

  const currentLevel = getCurrentLevelData();
  const [currentTermIndex, setCurrentTermIndex] = useState(0);
  const [guessedLetters, setGuessedLetters] = useState<string[]>([]);
  const [incorrectGuesses, setIncorrectGuesses] = useState(0);
  const [message, setMessage] = useState('');

  const maxIncorrectGuesses = 6;

  // Get current term to guess
  const getCurrentTerm = () => {
    if (difficulty === 'hard') {
      if (!hardTerms[currentTermIndex]) return '';
      return hardTerms[currentTermIndex].term.toLowerCase();
    } else {
      if (!currentLevel || !currentLevel.financialTerms[currentTermIndex]) return '';
      return currentLevel.financialTerms[currentTermIndex].term.toLowerCase();
    }
  };

  // Get current term's hint
  const getCurrentHint = () => {
    if (difficulty === 'hard') {
      if (!hardTerms[currentTermIndex]) return '';
      return hardTerms[currentTermIndex].hint;
    } else {
      if (!currentLevel || !currentLevel.financialTerms[currentTermIndex]) return '';
      return currentLevel.financialTerms[currentTermIndex].hint;
    }
  };

  // Reset the game for next term
  const resetForNextTerm = () => {
    setGuessedLetters([]);
    setIncorrectGuesses(0);
    setMessage('');
  };

  // Generate display word with blanks for unguessed letters
  const getDisplayWord = () => {
    const word = getCurrentTerm();
    return word
      .split('')
      .map(letter => (guessedLetters.includes(letter) ? letter : '_'))
      .join(' ');
  };

  // Handle letter guess
  const handleLetterGuess = (letter: string) => {
    // If already guessed, do nothing
    if (guessedLetters.includes(letter)) return;

    // Add letter to guessed letters
    setGuessedLetters([...guessedLetters, letter]);

    const word = getCurrentTerm();
    
    // Check if letter is in the word
    if (!word.includes(letter)) {
      setIncorrectGuesses(prev => prev + 1);
      
      // Check if max incorrect guesses reached
      if (incorrectGuesses + 1 >= maxIncorrectGuesses) {
        setMessage(`Game over! The word was: ${word}`);
        moveToNextTerm();
        // Clear message after 3 seconds
        setTimeout(() => {
          setMessage('');
        }, 3000);
      }
    } else {
      // Check if word is complete
      const newDisplayWord = word
        .split('')
        .map(char => (guessedLetters.includes(char) || char === letter ? char : '_'))
        .join('');
      
      if (!newDisplayWord.includes('_')) {
        setMessage('Correct! You found the word!');
        updateScore(3); // 3 points for correct word
        moveToNextTerm();
        // Clear message after 3 seconds
        setTimeout(() => {
          setMessage('');
        }, 3000);
      }
    }
  };

  // Move to next term
  const moveToNextTerm = () => {
    // If there are more terms in this level
    const maxTerms = difficulty === 'hard' ? hardTerms.length : currentLevel.financialTerms.length;
    if (currentTermIndex < maxTerms - 1) {
      setCurrentTermIndex(prev => prev + 1);
      resetForNextTerm();
    } else {
      // If this was the last term, mark term as found in game stats
      // This will trigger the level completion in the context
      currentLevel.financialTerms.forEach(term => {
        if (!gameStats.foundTerms.includes(term.term.toLowerCase())) {
          // Since we're at the end, just add all terms
          updateScore(0); // Don't add score, just mark as complete
        }
      });
      
      // Move to next level
      nextLevel();
    }
  };

  // Generate keyboard
  const generateKeyboard = () => {
    const keyboard = [
      ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
      ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
      ['Z', 'X', 'C', 'V', 'B', 'N', 'M']
    ];

    return (
      <div className="mt-4">
        {keyboard.map((row, rowIndex) => (
          <div key={rowIndex} className="flex justify-center mb-2">
            {row.map(letter => {
              const isGuessed = guessedLetters.includes(letter.toLowerCase());
              const isInWord = getCurrentTerm().includes(letter.toLowerCase());
              
              return (
                <Button
                  key={letter}
                  variant={isGuessed ? (isInWord ? "default" : "destructive") : "outline"}
                  size="sm"
                  className="m-1 w-10 h-10"
                  disabled={isGuessed || incorrectGuesses >= maxIncorrectGuesses || message.includes('Correct')}
                  onClick={() => handleLetterGuess(letter.toLowerCase())}
                >
                  {letter}
                </Button>
              );
            })}
          </div>
        ))}
      </div>
    );
  };

  // Reset game when level changes
  useEffect(() => {
    resetForNextTerm();
    setCurrentTermIndex(0);
  }, [currentLevel]);

  if (!currentLevel) return null;

  return (
    <Card className="w-full max-w-3xl">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">
            Level {gameStats.currentLevel}
          </CardTitle>
          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600">
              Incorrect: {incorrectGuesses}/{maxIncorrectGuesses}
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => window.location.href = '/'}
              className="flex items-center gap-1"
            >
              Exit
            </Button>
          </div>
        </div>
        <TimerBar />
      </CardHeader>
      
      <CardContent className="flex flex-col items-center">
        <div className="text-center mb-6">
          <p className="text-lg font-medium mb-4">{currentLevel.question}</p>
          <p className="text-sm text-gray-600">Hints used: {gameStats.hintsUsed}</p>
        </div>

        <div className="text-sm text-gray-600 mb-2">
          Incorrect: {incorrectGuesses}/{maxIncorrectGuesses}
        </div>
        
        <div className="text-2xl font-mono tracking-widest my-4">
          {getDisplayWord()}
        </div>
        
        {message && (
          <div className={`my-2 px-4 py-2 rounded-md ${message.includes('Correct') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
            {message}
          </div>
        )}
        
        {generateKeyboard()}
        
        <div className="mt-4 flex justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={showHint}
            className="flex items-center gap-1"
          >
            <LightbulbIcon size={16} />
            <span>Use Hint</span>
          </Button>
        </div>
        
        <div className="mt-4 text-center">
          <p className="text-sm text-gray-600">Hint: {getCurrentHint()}</p>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-end border-t pt-4">
        {gameStats.currentLevel < 5 && (
          <Button
            variant="outline"
            size="sm"
            onClick={nextLevel}
            className="flex items-center gap-1"
          >
            <span>Next</span>
            <ArrowRight size={16} />
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default HangmanGame;
