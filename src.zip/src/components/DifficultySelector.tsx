
import React from 'react';
import { useGame } from '@/context/GameContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';

const DifficultySelector: React.FC = () => {
  const { startGame, gameStats, difficulty } = useGame();

  return (
    <Card className="w-full max-w-2xl mx-auto p-6">
      <CardContent className="flex flex-col items-center space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative">
          {/* Connecting lines */}
          <div className="hidden md:block absolute top-1/2 left-1/3 right-2/3 h-0.5 transform -translate-y-1/2 transition-colors duration-300"
            style={{ backgroundColor: gameStats.easyCompleted ? '#22c55e' : (difficulty === 'medium' && !gameStats.mediumCompleted) ? '#eab308' : '#d1d5db' }} />
          <div className="hidden md:block absolute top-1/2 left-2/3 right-1/3 h-0.5 transform -translate-y-1/2 transition-colors duration-300"
            style={{ backgroundColor: gameStats.mediumCompleted ? '#22c55e' : (difficulty === 'hard' && !gameStats.hardCompleted) ? '#eab308' : '#d1d5db' }} />
          <Button
            className={cn(
              "w-48 py-4 text-lg rounded-md shadow-sm transition-all",
              gameStats.easyCompleted
                ? "bg-green-500 hover:bg-green-600"
                : difficulty === 'easy'
                  ? "bg-yellow-500 hover:bg-yellow-600"
                  : "bg-blue-500 hover:bg-blue-600"
            )}
            onClick={() => startGame('easy')}
          >
            Easy Level
          </Button>
          
          <Button
            className={cn(
              "w-48 py-4 text-lg rounded-md shadow-sm transition-all relative",
              gameStats.mediumCompleted
                ? "bg-green-500 hover:bg-green-600"
                : difficulty === 'medium'
                  ? "bg-yellow-500 hover:bg-yellow-600"
                  : gameStats.easyCompleted
                    ? "bg-blue-500 hover:bg-blue-600"
                    : "bg-gray-400 cursor-not-allowed"
            )}
            onClick={() => gameStats.easyCompleted && startGame('medium')}
            disabled={!gameStats.easyCompleted}
          >
            {!gameStats.easyCompleted && (
              <span className="absolute -top-2 -right-2 text-xl transition-opacity duration-300 opacity-0" style={{ opacity: !gameStats.easyCompleted ? 1 : 0 }}>🔒</span>
            )}
            Medium Level
          </Button>

          <Button
            className={cn(
              "w-48 py-4 text-lg rounded-md shadow-sm transition-all relative",
              gameStats.hardCompleted
                ? "bg-green-500 hover:bg-green-600"
                : difficulty === 'hard'
                  ? "bg-yellow-500 hover:bg-yellow-600"
                  : gameStats.mediumCompleted
                    ? "bg-blue-500 hover:bg-blue-600"
                    : "bg-gray-400 cursor-not-allowed"
            )}
            onClick={() => gameStats.mediumCompleted && startGame('hard')}
            disabled={!gameStats.mediumCompleted}
          >
            {!gameStats.mediumCompleted && (
              <span className="absolute -top-2 -right-2 text-xl transition-opacity duration-300 opacity-0" style={{ opacity: !gameStats.mediumCompleted ? 1 : 0 }}>🔒</span>
            )}
            Hard Level
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DifficultySelector;
