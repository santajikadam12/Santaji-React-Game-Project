import { useEffect } from 'react';
import { useGame } from '@/context/GameContext';
import { getRandomStories } from '../data/shortStories';

interface GameProps {
  gameKey: number;
}

const Game = ({ gameKey }: GameProps) => {
  const { 
    gameStats,
    difficulty,
    startGame,
    isGameActive
  } = useGame();

  useEffect(() => {
    if (!isGameActive && difficulty) {
      // Start a new game with fresh random stories
      startGame(difficulty);
    }
  }, [gameKey, difficulty, isGameActive, startGame]);

  if (!isGameActive || !difficulty) {
    return <div>Loading...</div>;
  }

  return (
    <div className="game-container">
      <div className="score-display">
        Score: {gameStats.score}
      </div>
      <div className="level-container">
        <h2>Level {gameStats.currentLevel}</h2>
        <div className="timer-section">
          <span>Found Terms: {gameStats.foundTerms.length}</span>
        </div>
        <div className="story-section">
          {difficulty && (
            <p>{gameStats.currentStory?.story || ''}</p>
          )}
          <div className="input-section">
            <input
              type="text"
              placeholder="Type a financial term..."
              className="term-input"
            />
            <button className="hint-button">Show Hint</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Game;