
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const GameInstructions: React.FC = () => {
  return (
    <Card className="w-full max-w-3xl bg-blue-50">
      <CardHeader>
        <CardTitle className="text-xl text-blue-700">How to Play:</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="list-disc list-inside space-y-2">
          <li>Find the hidden financial terms in each level</li>
          <li>You have 60 seconds to complete each level</li>
          <li>Use hints if you get stuck (costs points)</li>
          <li>Complete Easy level to unlock Medium, and Medium to unlock Hard</li>
          <li>Harder difficulties give more points per term</li>
        </ul>
        
        <div className="mt-4 space-y-2">
          <div>
            <h3 className="font-semibold">Easy Mode:</h3>
            <p className="text-sm text-gray-700">Find financial terms hidden in a story by typing them in.</p>
          </div>
          
          <div>
            <h3 className="font-semibold">Medium Mode:</h3>
            <p className="text-sm text-gray-700">Find financial terms based on single-word synonyms.</p>
          </div>
          
          <div>
            <h3 className="font-semibold">Hard Mode:</h3>
            <p className="text-sm text-gray-700">Guess the financial term letter by letter (hangman style).</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default GameInstructions;
