
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Home, Info } from 'lucide-react';
import { useGame } from '@/context/GameContext';

const Header: React.FC = () => {
  const navigate = useNavigate();
  const { gameStats } = useGame();
  
  return (
    <header className="w-full py-4 px-6 bg-white shadow-sm flex justify-between items-center">
      <div className="flex items-center">
        <span className="text-yellow-400 text-2xl mr-2">$</span>
        <h1 className="text-2xl font-bold text-blue-700">Financial Learning Games</h1>
      </div>
      
      <div className="flex items-center gap-3">
        <div className="mr-2 flex items-center">
          <span className="text-gray-600 mr-1">Score:</span>
          <span className="font-bold">{gameStats.score}</span>
        </div>
        
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center gap-1"
          onClick={() => navigate('/')}
        >
          <Home size={16} />
          <span>Home</span>
        </Button>
        
        <Button 
          variant="outline" 
          size="sm" 
          className="flex items-center gap-1"
          onClick={() => navigate('/about')}
        >
          <Info size={16} />
          <span>About</span>
        </Button>
      </div>
    </header>
  );
};

export default Header;
