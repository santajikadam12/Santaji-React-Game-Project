
import React from 'react';
import { useGame } from '@/context/GameContext';
import { Clock } from 'lucide-react';

const TimerBar: React.FC = () => {
  const { timer, timerColor } = useGame();
  
  // Calculate timer percentage
  const timerPercentage = (timer / 60) * 100;
  
  return (
    <div className="w-full mt-2 mb-4">
      <div className="flex justify-end items-center mb-1">
        <Clock size={16} className="mr-1" />
        <span className="text-sm font-medium">{timer} seconds remaining</span>
      </div>
      <div className="w-full h-2 bg-gray-200 rounded-full overflow-hidden">
        <div
          className={`h-full ${timerColor} transition-all duration-1000 ease-linear rounded-full`}
          style={{ width: `${timerPercentage}%` }}
        ></div>
      </div>
    </div>
  );
};

export default TimerBar;
