
import React, { useState, useEffect } from 'react';
import { useGame } from '@/context/GameContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { ArrowRight, LightbulbIcon } from 'lucide-react';
import TimerBar from './TimerBar';

const FindTermsGame: React.FC = () => {
  const { 
    getCurrentLevelData, 
    checkAnswer, 
    showHint, 
    gameStats, 
    difficulty,
    nextLevel
  } = useGame();
  
  const [answer, setAnswer] = useState<string>('');
  const currentLevel = getCurrentLevelData();
  
  // Reset answer input when level changes
  useEffect(() => {
    setAnswer('');
  }, [gameStats.currentLevel]);
  
  // Highlight found terms in story
  const highlightFoundTerms = (story: string) => {
    if (!story) return '';
    
    let highlightedStory = story;
    gameStats.foundTerms.forEach(term => {
      // Case insensitive replacement with span
      const regex = new RegExp(`(${term})`, 'gi');
      highlightedStory = highlightedStory.replace(regex, '<span class="bg-yellow-200 px-0.5 rounded">$1</span>');
    });
    
    return highlightedStory;
  };

  const [showSuccess, setShowSuccess] = useState(false);
  const [correctMessage, setCorrectMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (answer.trim()) {
      // Make sure to properly trim and normalize the answer
      const normalizedAnswer = answer.trim();
      const isCorrect = checkAnswer(normalizedAnswer);
      if (isCorrect) {
        const foundTerm = normalizedAnswer; // Store the found term
        setAnswer('');
        setShowSuccess(true);
        setCorrectMessage(`Correct! You found the term: ${foundTerm}`);
        // Auto-hide success message after 3 seconds
        setTimeout(() => {
          setShowSuccess(false);
          setCorrectMessage("");
        }, 3000);
      }
    }
  };

  if (!currentLevel) return null;

  return (
    <Card className="w-full max-w-3xl">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl">
            Level {gameStats.currentLevel}
          </CardTitle>
          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600">
              Found: {gameStats.foundTerms.length}/{currentLevel.financialTerms.length}
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button
                  variant="destructive"
                  size="sm"
                  className="flex items-center gap-1"
                >
                  Exit
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure you want to exit?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Your progress in the current level will be lost.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={() => window.location.href = '/'}>OK</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
        <TimerBar />
      </CardHeader>
      
      <CardContent>
        {difficulty === 'medium' ? (
          <div className="mb-6 mt-2 text-gray-800 leading-relaxed p-4 bg-gray-50 rounded-lg">
            <p className="font-medium mb-2">{currentLevel.question}</p>
          </div>
        ) : (
          <div className="mb-6 mt-2 text-gray-800 leading-relaxed p-4 bg-gray-50 rounded-lg">
            <div dangerouslySetInnerHTML={{ __html: highlightFoundTerms(currentLevel.story) }} />
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="flex gap-2 relative">
          <Input
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            placeholder="Type a financial term..."
            className="flex-1"
          />
          <Button type="submit">Submit</Button>
        </form>
        
        {/* Remove this success message */}
        {/* 
        {showSuccess && (
          <div className="mt-4 text-center text-green-600 bg-green-100 p-2 rounded">
            {correctMessage || "Correct! Term found!"}
          </div>
        )}
        */}
        <div className="mt-4 flex justify-center">
          <Button
            variant="outline"
            size="sm"
            onClick={showHint}
            className="flex items-center gap-1"
          >
            <LightbulbIcon size={16} />
            <span>Show Hint</span>
          </Button>
        </div>
      </CardContent>
      
      <CardFooter className="flex flex-col border-t pt-4">
        <div className="w-full flex justify-end mb-2">
          {gameStats.currentLevel < 5 && (
            <Button
              variant="outline"
              size="sm"
              onClick={nextLevel}
              className="flex items-center gap-1"
            >
              <span>Next</span>
              <ArrowRight size={16} />
            </Button>
          )}
        </div>
        
        {/* Success notification below the Next button */}
        {showSuccess && (
          <div className="w-full flex justify-end">
            <div className="bg-white rounded-md shadow-md p-3 max-w-xs">
              <div className="font-medium">Correct!</div>
              <div className="text-sm">You found the term: {correctMessage.split(': ')[1]}</div>
              {/* Removed the Current Score line */}
            </div>
          </div>
        )}
      </CardFooter>
    </Card>
  );
};

export default FindTermsGame;
