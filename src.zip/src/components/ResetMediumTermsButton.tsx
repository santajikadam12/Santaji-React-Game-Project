import React from 'react';
import { Button } from '@/components/ui/button';
import { useGame } from '@/context/GameContext';
import { RefreshCw } from 'lucide-react';

interface ResetMediumTermsButtonProps {
  className?: string;
}

/**
 * Button component that allows users to reset their medium level terms
 * This gives each user a new set of random financial terms
 */
const ResetMediumTermsButton: React.FC<ResetMediumTermsButtonProps> = ({ className }) => {
  const { resetMediumTerms } = useGame();

  return (
    <Button
      variant="outline"
      size="sm"
      onClick={resetMediumTerms}
      className={`flex items-center gap-1 ${className || ''}`}
    >
      <RefreshCw size={16} />
      <span>Reset Medium Terms</span>
    </Button>
  );
};

export default ResetMediumTermsButton;