import React from 'react';
import { useGame } from '@/context/GameContext';
import { cn } from '@/lib/utils';

const Stepper: React.FC = () => {
  const { gameStats, difficulty } = useGame();

  const steps = [
    { label: 'Easy', completed: gameStats.easyCompleted },
    { label: 'Medium', completed: gameStats.mediumCompleted, locked: !gameStats.easyCompleted },
    { label: 'Hard', completed: gameStats.hardCompleted, locked: !gameStats.mediumCompleted }
  ];

  return (
    <div className="flex items-center justify-center w-full mb-8">
      {steps.map((step, index) => (
        <React.Fragment key={step.label}>
          <div className="flex flex-col items-center gap-2">
            <div
              className={cn(
                'w-24 h-10 rounded flex items-center justify-center text-sm font-medium border transition-all duration-300',
                step.label === 'Easy' && !step.completed ? 'bg-yellow-500 text-white border-yellow-600' :
                step.completed && step.label === 'Easy' ? 'bg-green-500 text-white border-green-600' :
                step.label === 'Medium' && gameStats.easyCompleted ? 'bg-green-500 text-white border-green-600' :
                step.completed && step.label === 'Hard' ? 'bg-red-500 text-white border-red-600' :
                step.locked ? 'bg-gray-200 text-gray-500 border-gray-300' :
                difficulty === step.label.toLowerCase() ? 'bg-blue-500 text-white border-blue-600' :
                'bg-white text-gray-700 border-gray-300'
              )}
            >
              {step.completed ? '✓ ' + step.label : 
               (step.locked && !((step.label === 'Medium' && gameStats.easyCompleted) || 
                               (step.label === 'Hard' && gameStats.mediumCompleted))) ? '🔒 ' + step.label : 
               step.label}
            </div>
          </div>
          {index < steps.length - 1 && (
            <div
              className={cn(
                'h-1 w-16 mx-2 transition-all duration-300',
                step.completed && step.label === 'Easy' ? 'bg-green-500' :
                step.label === 'Easy' && gameStats.easyCompleted ? 'bg-green-500' :
                step.label === 'Medium' && gameStats.mediumCompleted ? 'bg-green-500' :
                step.completed && step.label === 'Hard' ? 'bg-red-500' :
                'bg-gray-300'
              )}
            />
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export default Stepper;