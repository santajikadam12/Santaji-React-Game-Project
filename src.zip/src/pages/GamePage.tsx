
import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import FindTermsGame from '@/components/FindTermsGame';
import HangmanGame from '@/components/HangmanGame';
import { useGame } from '@/context/GameContext';
import { Difficulty } from '@/types/game';
import Stepper from '@/components/ui/stepper';

const GamePage: React.FC = () => {
  const { difficulty: routeDifficulty } = useParams<{ difficulty: string }>();
  const { difficulty, startGame } = useGame();
  
  // Validate difficulty from URL
  const isValidDifficulty = ['easy', 'medium', 'hard'].includes(routeDifficulty || '');
  
  // Redirect to home if invalid difficulty
  if (!isValidDifficulty) {
    return <Navigate to="/" />;
  }
  
  // If game context difficulty doesn't match URL, set it
  if (difficulty !== routeDifficulty) {
    startGame(routeDifficulty as Difficulty);
  }
  
  let GameComponent;
  switch (routeDifficulty) {
    case 'easy':
    case 'medium':
      GameComponent = FindTermsGame;
      break;
    case 'hard':
      GameComponent = HangmanGame;
      break;
    default:
      return <Navigate to="/" />;
  }
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="mb-6">
            <Stepper />
          </div>
          <GameComponent />
        </div>
      </main>
    </div>
  );
};

export default GamePage;
