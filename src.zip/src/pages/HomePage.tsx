
import React from 'react';
import Header from '@/components/Header';
import GameInstructions from '@/components/GameInstructions';
import { useGame } from '@/context/GameContext';
import { Button } from '@/components/ui/button';

const HomePage: React.FC = () => {
  const { gameStats, startGame } = useGame();
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-blue-700 mb-2">
            <span className="text-yellow-400 mr-2">$</span>
            Financial Learning Games
          </h1>
          <p className="text-gray-600">Test your knowledge of financial terms!</p>
          
          <div className="mt-4">
            <p className="text-lg">Your current score: <span className="font-bold">{gameStats.score}</span></p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 gap-8 max-w-4xl mx-auto">
          <div className="flex justify-center mb-8">
            <Button
              className="w-48 py-6 text-xl rounded-md shadow-lg transition-all bg-blue-600 hover:bg-blue-700"
              onClick={() => startGame('easy')}
            >
              Start Game
            </Button>
          </div>
          <GameInstructions />
        </div>
      </main>
    </div>
  );
};

export default HomePage;
