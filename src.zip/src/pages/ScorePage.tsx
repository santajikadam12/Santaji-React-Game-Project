
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Header from '@/components/Header';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trophy, Home, RotateCcw } from 'lucide-react';
import { useGame } from '@/context/GameContext';

const ScorePage: React.FC = () => {
  const navigate = useNavigate();
  const { gameStats, resetGame } = useGame();
  
  const handlePlayAgain = () => {
    resetGame();
    navigate('/');
  };
  
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto py-8 px-4 flex justify-center items-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Trophy className="w-16 h-16 text-yellow-400 mx-auto mb-4" />
            <CardTitle className="text-2xl text-blue-700">Game Completed!</CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-4 text-center">
            {gameStats.hardCompleted ? (
              <>
                <div className="text-5xl font-bold py-6">{gameStats.score}</div>
                <p className="text-gray-600">Congratulations! You've completed all levels.</p>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Easy  Score: {gameStats.levelScores.easy}</p>
                  <p className="text-sm text-gray-600">Medium  Score: {gameStats.levelScores.medium}</p>
                  <p className="text-sm text-gray-600">Hard  {gameStats.levelScores.hard}</p>
                </div>
                <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-semibold mb-2">Achievement Unlocked</h3>
                  <p className="text-sm">Financial Wizard: Master of Financial Terms</p>
                </div>
              </>
            ) : (
              <>
                <div className="text-5xl font-bold py-6">
                  {gameStats.levelScores[gameStats.difficulty || 'easy']}
                </div>
                <p className="text-gray-600">Current Level Score</p>
                <p className="text-sm text-gray-500">
                  Complete all levels to see your total score!
                </p>
              </>
            )}
          </CardContent>
          
          <CardFooter className="flex justify-center gap-4">
            <Button
              variant="outline"
              className="flex items-center gap-2"
              onClick={() => navigate('/')}
            >
              <Home size={16} />
              <span>Home</span>
            </Button>
            
            <Button
              className="flex items-center gap-2"
              onClick={handlePlayAgain}
            >
              <RotateCcw size={16} />
              <span>Play Again</span>
            </Button>
          </CardFooter>
        </Card>
      </main>
    </div>
  );
};

export default ScorePage;
