
import React from 'react';
import Header from '@/components/Header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      
      <main className="flex-1 container mx-auto py-8 px-4">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl text-blue-700">About Financial Learning Games</CardTitle>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <p>
              Financial Learning Games is an educational game designed to help you learn and master financial terminology in an engaging and fun way. 
              Whether you're a finance student, professional, or just looking to improve your financial literacy, this game offers a challenging 
              and entertaining way to expand your financial vocabulary.
            </p>
            
            <h3 className="text-lg font-semibold mt-4">Why Play Financial Learning Games?</h3>
            
            <ul className="list-disc list-inside space-y-2">
              <li>Expand your financial vocabulary in an engaging way</li>
              <li>Learn important financial concepts through context</li>
              <li>Challenge yourself with progressively difficult levels</li>
              <li>Improve your financial literacy and decision-making</li>
              <li>Make learning financial terms fun and memorable</li>
            </ul>
            
            <h3 className="text-lg font-semibold mt-4">Benefits of Financial Literacy</h3>
            
            <p>
              Financial literacy is a crucial life skill that helps you make informed decisions about money management, investments, and 
              planning for the future. By playing Financial Learning Games, you're taking a step toward better understanding the language of finance, 
              which can help you:
            </p>
            
            <ul className="list-disc list-inside space-y-2">
              <li>Make better financial decisions</li>
              <li>Understand investment opportunities</li>
              <li>Communicate effectively about financial matters</li>
              <li>Navigate complex financial products and services</li>
              <li>Plan for long-term financial goals</li>
            </ul>
            
            <p className="mt-4">
              Start playing today and turn learning financial terms into an enjoyable experience!
            </p>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default AboutPage;
