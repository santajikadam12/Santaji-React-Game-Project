import { FinancialTerm } from '../types/game';
import { hardTerms } from './hardTerms';

// Store user-specific hard term selections
type UserHardTermsStore = {
  hardTerms: FinancialTerm[];
  userId: string | null;
};

// Initialize with empty state
const userHardTermsStore: UserHardTermsStore = {
  hardTerms: [],
  userId: null
};

/**
 * Get the current user ID from localStorage
 */
export const getUserId = (): string => {
  let userId = localStorage.getItem('fin_terms_user_id');
  if (!userId) {
    userId = Date.now().toString(36) + Math.random().toString(36).substring(2);
    localStorage.setItem('fin_terms_user_id', userId);
  }
  return userId;
};

/**
 * Select random terms for a specific user
 * This ensures each user gets a consistent set of terms
 * @param count Number of terms to select
 * @returns Array of selected financial terms
 */
export const getUserHardTerms = (count: number = 5): FinancialTerm[] => {
  const userId = getUserId();
  
  // If we already have terms for this user, return them
  if (userHardTermsStore.userId === userId && userHardTermsStore.hardTerms.length > 0) {
    return userHardTermsStore.hardTerms;
  }
  
  // Create a copy of the terms array to avoid modifying the original
  const termsCopy = [...hardTerms];
  const result: FinancialTerm[] = [];
  
  // Shuffle the array using Fisher-Yates algorithm with user ID as seed
  for (let i = termsCopy.length - 1; i > 0; i--) {
    const seed = userId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const j = Math.floor((seed * (i + 1)) % (i + 1));
    [termsCopy[i], termsCopy[j]] = [termsCopy[j], termsCopy[i]];
  }
  
  // Take the first 'count' elements
  for (let i = 0; i < count && i < termsCopy.length; i++) {
    result.push({
      ...termsCopy[i],
      id: `h${i+1}-${userId.substring(0, 5)}` // Generate a unique ID with user prefix
    });
  }
  
  // Store the selected terms for this user
  userHardTermsStore.userId = userId;
  userHardTermsStore.hardTerms = result;
  
  return result;
};

/**
 * Clear the user's term selection
 * This can be used when the user wants to reset their game
 */
export const clearUserHardTerms = (): void => {
  userHardTermsStore.hardTerms = [];
  userHardTermsStore.userId = null;
};