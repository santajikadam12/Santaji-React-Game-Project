import { GameData } from '../types/game';

export const shortFinancialStories = [
 

  {
    id: "1",
    story: "Tom opened his first savings account at the local credit union. He was excited to start building his emergency fund for unexpected expenses. The bank offered a competitive interest rate on his deposits. Tom knew the importance of financial literacy in managing his money wisely.",
    financialTerms: [
      { id: "s1-1", term: "savings account", hint: "A bank account that earns interest on deposited funds" },
      { id: "s1-2", term: "credit union", hint: "A member-owned financial cooperative" },
      { id: "s1-3", term: "emergency fund", hint: "Money set aside for unexpected expenses" },
      { id: "s1-4", term: "expenses", hint: "Money spent on goods and services" },
      { id: "s1-5", term: "bank", hint: "A financial institution that accepts deposits and makes loans" },
      { id: "s1-6", term: "interest rate", hint: "Percentage charged for borrowing money or paid for saving money" },
      { id: "s1-7", term: "deposits", hint: "Money placed into a bank account" },
      { id: "s1-8", term: "financial literacy", hint: "Understanding how to manage money effectively" }
    ]
  },
  {
    id: "2",
    story: "Ryan learned about different banking account options for his needs. He compared interest rates on high-yield savings accounts from online banks. The money market account offered check-writing privileges with competitive returns. Ryan maintained a minimum balance to avoid monthly maintenance fees.",
    financialTerms: [
      { id: "s2-1", term: "banking account", hint: "Financial account at a bank" },
      { id: "s2-2", term: "interest rates", hint: "Percentage paid on saved money" },
      { id: "s2-3", term: "high-yield savings accounts", hint: "Savings accounts with above-average interest" },
      { id: "s2-4", term: "online banks", hint: "Banks operating primarily through the internet" },
      { id: "s2-5", term: "money market account", hint: "Deposit account with higher interest and limited withdrawals" },
      { id: "s2-6", term: "check-writing privileges", hint: "Ability to write checks from an account" },
      { id: "s2-7", term: "competitive returns", hint: "Favorable investment earnings" },
      { id: "s2-8", term: "minimum balance", hint: "Lowest amount required in account" },
      { id: "s2-9", term: "maintenance fees", hint: "Regular charges for account services" }
    ]
  },
  {
    id: "3",
    story: "Marcus explored quantitative equity strategies. He studied factor models and statistical arbitrage. Understanding market neutrality helped his portfolio design. He developed systematic trading algorithms.",
    financialTerms: [
      { id: "s3-1", term: "quantitative equity", hint: "Investment strategies using mathematical models" },
      { id: "s3-2", term: "factor models", hint: "Mathematical tools for analyzing investment risks" },
      { id: "s3-3", term: "statistical arbitrage", hint: "Trading strategy exploiting price differences" },
      { id: "s3-4", term: "market neutrality", hint: "Strategy minimizing market exposure" },
      { id: "s3-5", term: "portfolio design", hint: "Process of constructing investment portfolios" },
      { id: "s3-6", term: "systematic trading", hint: "Rule-based automated trading approach" }
    ]
  },

 
  {
    id: "4",
    story: "Sarah started her retirement planning journey. She learned about different types of retirement accounts and contribution limits. The power of compound interest amazed her. She understood the importance of starting early for long-term wealth building.",
    financialTerms: [
      { id: "s4-1", term: "retirement planning", hint: "Process of preparing for life after work" },
      { id: "s4-2", term: "retirement accounts", hint: "Special accounts for retirement savings" },
      { id: "s4-3", term: "contribution limits", hint: "Maximum allowed retirement account deposits" },
      { id: "s4-4", term: "compound interest", hint: "Interest earned on previous interest" },
      { id: "s4-5", term: "long-term", hint: "Extended period of time" },
      { id: "s4-6", term: "wealth building", hint: "Process of growing assets over time" }
    ]
  },
  {
    id: "5",
    story: "David explored cryptocurrency investments. He studied blockchain technology and digital wallets. Understanding market volatility helped his risk management. He learned about secure storage and private keys.",
    financialTerms: [
      { id: "s5-1", term: "cryptocurrency investments", hint: "Investing in digital currencies" },
      { id: "s5-2", term: "blockchain technology", hint: "System for recording cryptocurrency transactions" },
      { id: "s5-3", term: "digital wallets", hint: "Software for storing digital currency" },
      { id: "s5-4", term: "market volatility", hint: "Price fluctuation in markets" },
      { id: "s5-5", term: "risk management", hint: "Strategies to handle potential losses" },
      { id: "s5-6", term: "secure storage", hint: "Safe keeping of digital assets" },
      { id: "s5-7", term: "private keys", hint: "Secret codes for accessing digital assets" },
      { id: "s5-8", term: "cryptocurrency", hint: "Digital or virtual currency" }
    ]
  },
  {
    id: "6",
    story: "Emma learned about tax-advantaged accounts. She maximized her contributions to retirement plans. Understanding tax deductions improved her financial planning. She explored various investment vehicles for tax efficiency.",
    financialTerms: [
      { id: "s6-1", term: "tax-advantaged accounts", hint: "Accounts with special tax benefits" },
      { id: "s6-2", term: "contributions", hint: "Money added to investment accounts" },
      { id: "s6-3", term: "retirement plans", hint: "Long-term savings arrangements" },
      { id: "s6-4", term: "tax deductions", hint: "Expenses that reduce taxable income" },
      { id: "s6-5", term: "financial planning", hint: "Strategy for managing money" },
      { id: "s6-6", term: "investment vehicles", hint: "Different types of investments" },
      { id: "s6-7", term: "tax efficiency", hint: "Minimizing tax impact on investments" }
    ]
  },
  {
      id: "7",
      story: "Michael ventured into real estate investing. He analyzed property values and rental income potential. Understanding mortgage terms helped his investment decisions. He learned about property management and maintenance costs.",
      financialTerms: [
        { id: "s7-1", term: "real estate investing", hint: "Buying property for profit" },
        { id: "s7-2", term: "property values", hint: "Worth of real estate assets" },
        { id: "s7-3", term: "rental income", hint: "Money earned from renting property" },
        { id: "s7-4", term: "mortgage", hint: "Loan for buying property" },
        { id: "s7-5", term: "property management", hint: "Overseeing real estate assets" },
        { id: "s7-6", term: "maintenance costs", hint: "Expenses for upkeep" }
      ]
    },
    {
      id: "8",
      story: "Lisa studied debt consolidation strategies. She compared interest rates from different lenders. Understanding credit scores improved her loan terms. She created a debt repayment plan.",
      financialTerms: [
        { id: "s8-1", term: "debt consolidation", hint: "Combining multiple debts" },
        { id: "s8-2", term: "interest rates", hint: "Percentage charged on borrowed money" },
        { id: "s8-3", term: "lenders", hint: "Organizations that provide loans" },
        { id: "s8-4", term: "credit scores", hint: "Measure of creditworthiness" },
        { id: "s8-5", term: "loan terms", hint: "Conditions of borrowing money" },
        { id: "s8-6", term: "debt repayment", hint: "Paying back borrowed money" }
      ]
    },
    {
      id: "9",
      story: "James explored options trading strategies. He learned about puts and calls. Understanding strike prices helped his trading decisions. He studied options Greeks for risk assessment.",
      financialTerms: [
        { id: "s9-1", term: "options trading strategies", hint: "Methods for trading contract rights" },
        { id: "s9-2", term: "puts", hint: "Right to sell assets" },
        { id: "s9-3", term: "calls", hint: "Right to buy assets" },
        { id: "s9-4", term: "strike prices", hint: "Predetermined trading price" },
        { id: "s9-5", term: "trading decisions", hint: "Investment choices" },
        { id: "s9-6", term: "options Greeks", hint: "Risk measurements" },
        { id: "s9-7", term: "risk assessment", hint: "Evaluating potential losses" }
      ]
    },
    {
      id: "10",
      story: "Rachel started her own small business. She created a business plan and budget. Understanding cash flow management was crucial. She learned about business taxes and licenses.",
      financialTerms: [
        { id: "s10-1", term: "small business", hint: "Independent enterprise" },
        { id: "s10-2", term: "business plan", hint: "Strategic company document" },
        { id: "s10-3", term: "budget", hint: "Financial planning tool" },
        { id: "s10-4", term: "cash flow management", hint: "Money movement control" },
        { id: "s10-5", term: "business taxes", hint: "Company tax obligations" },
        { id: "s10-6", term: "licenses", hint: "Legal business permits" }
      ]
    },
    {
       id: "11",
       story: "Anna explored health insurance options. She compared deductibles and copayments. Understanding coverage networks helped her decision. She learned about health savings accounts.",
       financialTerms: [
         { id: "s11-1", term: "health insurance", hint: "Medical cost coverage" },
         { id: "s11-2", term: "deductibles", hint: "Initial payment amount" },
         { id: "s11-3", term: "copayments", hint: "Fixed payment portion" },
         { id: "s11-4", term: "coverage networks", hint: "Approved healthcare providers" },
         { id: "s11-5", term: "health savings accounts", hint: "Tax-advantaged medical savings" }
       ]
     },
     {
       id: "12",
       story: "Peter studied international investing. He learned about currency exchange rates and global markets. Understanding geopolitical risks improved his strategy. He explored emerging market opportunities.",
       financialTerms: [
         { id: "s12-1", term: "international investing", hint: "Global market participation" },
         { id: "s12-2", term: "exchange rates", hint: "Currency value ratios" },
         { id: "s12-3", term: "geopolitical risks", hint: "Political investment impacts" },
         { id: "s12-4", term: "emerging markets", hint: "Developing economies" },
         { id: "s12-5", term: "global markets", hint: "Worldwide trading venues" },
         { id: "s12-6", term: "currency risk", hint: "Exchange rate fluctuation exposure" },
         { id: "s12-7", term: "market volatility", hint: "Price fluctuation intensity" },
         { id: "s12-8", term: "international diversification", hint: "Global investment spreading" }
       ]
     },
     {
       id: "13",
       story: "Maria created an estate plan. She wrote a will and established trusts. Understanding beneficiary designations was important. She learned about power of attorney.",
       financialTerms: [
         { id: "s13-1", term: "estate plan", hint: "Asset transfer strategy" },
         { id: "s13-2", term: "will", hint: "Legal inheritance document" },
         { id: "s13-3", term: "trusts", hint: "Asset management arrangements" },
         { id: "s13-4", term: "beneficiary", hint: "Inheritance recipient" },
         { id: "s13-5", term: "power of attorney", hint: "Legal authority designation" }
       ]
     },
     {
       id: "14",
       story: "Alex studied forex trading strategies. He learned about currency pairs and exchange rates. Understanding leverage risks improved his trading approach. He developed a disciplined trading plan with risk management.",
       financialTerms: [
         { id: "s14-1", term: "forex trading", hint: "Foreign currency exchange" },
         { id: "s14-2", term: "currency pairs", hint: "Two currencies being traded" },
         { id: "s14-3", term: "exchange rates", hint: "Currency conversion prices" },
         { id: "s14-4", term: "leverage risks", hint: "Borrowed money dangers" },
         { id: "s14-5", term: "trading plan", hint: "Strategic investment guide" },
         { id: "s14-6", term: "risk management", hint: "Loss prevention strategy" }
       ]
     },
     {
       id: "15",
       story: "Sophie explored sustainable investing options. She researched environmental and social governance criteria. Understanding impact investing shaped her portfolio choices. She balanced financial returns with ethical considerations.",
       financialTerms: [
         { id: "s15-1", term: "sustainable investing", hint: "Responsible investment approach" },
         { id: "s15-2", term: "environmental governance", hint: "Ecological management standards" },
         { id: "s15-3", term: "social governance", hint: "Community impact factors" },
         { id: "s15-4", term: "impact investing", hint: "Purpose-driven investments" },
         { id: "s15-5", term: "portfolio choices", hint: "Investment selection decisions" },
         { id: "s15-6", term: "ethical considerations", hint: "Moral investment factors" }
       ]
     },
     {
       id: "16",
       story: "Daniel researched commodity markets. He studied supply and demand dynamics. Understanding futures contracts improved his trading strategy. He learned about commodity storage and delivery costs.",
       financialTerms: [
         { id: "s16-1", term: "commodity markets", hint: "Raw materials trading" },
         { id: "s16-2", term: "supply and demand", hint: "Market forces balance" },
         { id: "s16-3", term: "futures contracts", hint: "Future delivery agreements" },
         { id: "s16-4", term: "trading strategy", hint: "Investment approach plan" },
         { id: "s16-5", term: "storage costs", hint: "Holding expenses" },
         { id: "s16-6", term: "delivery costs", hint: "Transportation expenses" }
       ]
     },
      {
        id: "17",
        story: "Emily explored fintech innovations. She studied mobile payment systems and digital banking platforms. Understanding blockchain applications improved her tech perspective. She learned about cybersecurity in financial transactions.",
        financialTerms: [
          { id: "s17-1", term: "fintech", hint: "Financial technology solutions" },
          { id: "s17-2", term: "mobile payments", hint: "Smartphone transaction systems" },
          { id: "s17-3", term: "digital banking", hint: "Online financial services" },
          { id: "s17-4", term: "blockchain applications", hint: "Distributed ledger uses" },
          { id: "s17-5", term: "cybersecurity", hint: "Digital protection measures" },
          { id: "s17-6", term: "financial transactions", hint: "Money exchange activities" }
        ]
      },
      {
        id: "18",
        story: "Jack studied alternative investments. He researched private equity and venture capital opportunities. Understanding hedge fund strategies broadened his perspective. He learned about risk-adjusted returns and diversification benefits.",
        financialTerms: [
          { id: "s18-1", term: "alternative investments", hint: "Non-traditional assets" },
          { id: "s18-2", term: "private equity", hint: "Private company ownership" },
          { id: "s18-3", term: "venture capital", hint: "Startup funding" },
          { id: "s18-4", term: "hedge fund strategies", hint: "Investment partnership tactics" },
          { id: "s18-5", term: "risk-adjusted returns", hint: "Performance versus risk" },
          { id: "s18-6", term: "diversification benefits", hint: "Risk reduction advantages" }
        ]
      },
      {
        id: "19",
        story: "Nina learned about risk management techniques. She studied hedging strategies and portfolio insurance. Understanding correlation helped her diversification approach. She developed contingency plans for market stress.",
        financialTerms: [
          { id: "s19-1", term: "risk management", hint: "Loss prevention strategies" },
          { id: "s19-2", term: "hedging strategies", hint: "Risk reduction techniques" },
          { id: "s19-3", term: "portfolio insurance", hint: "Investment protection" },
          { id: "s19-4", term: "correlation", hint: "Relationship between assets" },
          { id: "s19-5", term: "diversification approach", hint: "Risk spreading method" },
          { id: "s19-6", term: "contingency plans", hint: "Backup strategies" },
          { id: "s19-7", term: "market stress", hint: "Extreme market conditions" }
        ]
      },
      {
        id: "20",
        story: "Oliver studied behavioral finance principles. He learned about cognitive biases affecting investment decisions. Understanding market psychology helped him avoid emotional trading. He developed a disciplined investment approach based on rational analysis.",
        financialTerms: [
          { id: "s20-1", term: "behavioral finance", hint: "Psychology of financial decisions" },
          { id: "s20-2", term: "cognitive biases", hint: "Mental shortcuts affecting judgment" },
          { id: "s20-3", term: "market psychology", hint: "Collective investor mindset" },
          { id: "s20-4", term: "emotional trading", hint: "Feeling-based investment decisions" },
          { id: "s20-5", term: "rational analysis", hint: "Logical decision-making process" },
          { id: "s20-6", term: "investment decisions", hint: "Choices made about investing money" },
          { id: "s20-7", term: "disciplined investment", hint: "Systematic approach to investing" }
        ]
      },
      {
        id: "21",
        story: "Zoe explored decentralized finance applications. She studied yield farming and liquidity pools. Understanding smart contracts was essential for her DeFi participation. She learned about governance tokens and protocol risks.",
        financialTerms: [
          { id: "s21-1", term: "decentralized finance", hint: "Blockchain-based financial systems" },
          { id: "s21-2", term: "yield farming", hint: "Crypto asset optimization" },
          { id: "s21-3", term: "liquidity pools", hint: "Shared token reserves" },
          { id: "s21-4", term: "smart contracts", hint: "Self-executing code agreements" },
          { id: "s21-5", term: "governance tokens", hint: "Voting rights tokens" },
          { id: "s21-6", term: "protocol risks", hint: "System vulnerability dangers" }
        ]
      },
      {
        id: "22",
        story: "William studied algorithmic trading systems. He learned about backtesting strategies and execution algorithms. Understanding latency issues improved his high-frequency approach. He developed robust risk controls for automated trading.",
        financialTerms: [
          { id: "s22-1", term: "algorithmic trading systems", hint: "Computer-automated investing platforms" },
          { id: "s22-2", term: "backtesting strategies", hint: "Historical strategy validation methods" },
          { id: "s22-3", term: "execution algorithms", hint: "Order processing systems" },
          { id: "s22-4", term: "latency issues", hint: "Time delay problems" },
          { id: "s22-5", term: "high-frequency approach", hint: "Rapid trading methodology" },
          { id: "s22-6", term: "risk controls", hint: "Loss prevention mechanisms" },
          { id: "s22-7", term: "automated trading", hint: "Computer-controlled trading" }
        ]
      },
      
       {
        id: "23",
        story: "Mia explored robo-advisory platforms for investing. She compared automated portfolio management services and fee structures. Understanding asset allocation algorithms shaped her investment choices. She monitored performance benchmarks regularly.",
        financialTerms: [
          { id: "s23-1", term: "robo-advisory platforms", hint: "Automated investment management systems" },
          { id: "s23-2", term: "portfolio management services", hint: "Professional investment oversight" },
          { id: "s23-3", term: "fee structures", hint: "Cost arrangement systems" },
          { id: "s23-4", term: "asset allocation algorithms", hint: "Investment distribution formulas" },
          { id: "s23-5", term: "investment choices", hint: "Investment selection decisions" },
          { id: "s23-6", term: "performance benchmarks", hint: "Standards for measuring investment results" },
          { id: "s23-7", term: "investing", hint: "Putting money into assets for returns" }
        ]
      },
      {
        id: "24",
        story: "Ethan studied financial derivatives markets. He learned about swaps and structured products. Understanding counterparty risk improved his derivatives strategy. He developed models for pricing complex instruments.",
        financialTerms: [
          { id: "s24-1", term: "financial derivatives", hint: "Contracts deriving value from underlying assets" },
          { id: "s24-2", term: "swaps", hint: "Agreements to exchange financial instruments" },
          { id: "s24-3", term: "structured products", hint: "Complex financial instruments combining multiple assets" },
          { id: "s24-4", term: "counterparty risk", hint: "Potential for trading partner default" },
          { id: "s24-5", term: "derivatives strategy", hint: "Plan for using derivative instruments" },
          { id: "s24-6", term: "models", hint: "Mathematical frameworks for valuation" },
          { id: "s24-7", term: "complex instruments", hint: "Sophisticated financial products" }
        ],
        
      },
       
      {
        id: "25",
        story: "Olivia explored retirement planning strategies. She compared traditional and Roth IRA options. Understanding tax implications helped her decision-making process. She created a diversified retirement portfolio with long-term growth potential.",
        financialTerms: [
          { id: "s25-1", term: "retirement planning strategies", hint: "Methods for preparing for retirement" },
          { id: "s25-2", term: "traditional IRA", hint: "Tax-deferred retirement account" },
          { id: "s25-3", term: "Roth IRA", hint: "After-tax retirement account" },
          { id: "s25-4", term: "tax implications", hint: "Tax consequences of financial decisions" },
          { id: "s25-5", term: "diversified retirement portfolio", hint: "Varied retirement investment collection" },
          { id: "s25-6", term: "long-term growth potential", hint: "Future value increase possibility" }
          
        ],
        },
      {
        id: "26",
        story: "Noah studied real estate investment trusts. He analyzed dividend yields and property portfolios. Understanding market cycles improved his investment timing. He developed strategies for passive income through REIT investments.",
        financialTerms: [
          { id: "s26-1", term: "real estate investment trusts", hint: "Property-focused companies" },
          { id: "s26-2", term: "dividend yields", hint: "Income return percentages" },
          { id: "s26-3", term: "property portfolios", hint: "Real estate asset collections" },
          { id: "s26-4", term: "market cycles", hint: "Economic pattern periods" },
          { id: "s26-5", term: "investment timing", hint: "Strategic entry points" },
          { id: "s26-6", term: "passive income", hint: "Effort-minimal earnings" }
        ]
      },
      {
        id: "27",
        story: "Ava explored municipal bond investments. She compared tax-exempt yields with taxable alternatives. Understanding credit ratings helped her risk assessment. She developed a laddered bond strategy for consistent income.",
      financialTerms: [
        { id: "s27-1", term: "municipal bond investments", hint: "Local government debt securities" },
        { id: "s27-2", term: "tax-exempt yields", hint: "Returns free from taxation" },
        { id: "s27-3", term: "taxable alternatives", hint: "Investments subject to taxation" },
        { id: "s27-4", term: "credit ratings", hint: "Creditworthiness assessments" },
        { id: "s27-5", term: "risk assessment", hint: "Evaluation of potential losses" },
        { id: "s27-6", term: "laddered bond strategy", hint: "Staggered maturity investment approach" },
        { id: "s27-7", term: "consistent income", hint: "Regular investment returns" },
         
      ],
        },
       {
         id: "28",
        story: "Liam studied value investing principles. He analyzed financial statements and intrinsic value calculations. Understanding margin of safety concepts improved his stock selection. He developed a long-term investment philosophy based on fundamental analysis.",
        financialTerms: [
          { id: "s28-1", term: "value investing principles", hint: "Investment approach focusing on undervalued assets" },
          { id: "s28-2", term: "financial statements", hint: "Documents showing company's financial position" },
          { id: "s28-3", term: "intrinsic value calculations", hint: "Methods to determine true asset worth" },
          { id: "s28-4", term: "margin of safety concepts", hint: "Buffer between price and estimated value" },
          { id: "s28-5", term: "stock selection", hint: "Process of choosing investments" },
          { id: "s28-6", term: "long-term investment philosophy", hint: "Strategy focused on extended time horizons" },
          { id: "s28-7", term: "fundamental analysis", hint: "Evaluation of company's underlying factors" }
        ]
      },
      {
        id: "29",
        story: "Emma explored tax-loss harvesting strategies. She studied capital gains treatment and wash sale rules. Understanding tax-efficient investing improved her after-tax returns. She developed a systematic approach to portfolio tax management.",
        financialTerms: [
          { id: "s29-1", term: "tax-loss harvesting", hint: "Strategic loss realization" },
          { id: "s29-2", term: "capital gains", hint: "Investment profit increases" },
          { id: "s29-3", term: "wash sale", hint: "Repurchase restriction rule" },
          { id: "s29-4", term: "tax-efficient investing", hint: "Burden-minimizing approach" },
          { id: "s29-5", term: "after-tax returns", hint: "Post-obligation profits" },
          { id: "s29-6", term: "portfolio tax management", hint: "Investment levy optimization" }
        ]
      },
      {
        id: "30",
        story: "Mason studied technical analysis patterns. He analyzed chart formations and momentum indicators. Understanding support and resistance levels improved his entry points. He developed a rules-based trading system with risk management protocols.",
        financialTerms: [
          { id: "s30-1", term: "technical analysis", hint: "Chart-based prediction" },
          { id: "s30-2", term: "chart formations", hint: "Price pattern shapes" },
          { id: "s30-3", term: "momentum indicators", hint: "Trend strength measurements" },
          { id: "s30-4", term: "support levels", hint: "Price floor points" },
          { id: "s30-5", term: "resistance levels", hint: "Price ceiling barriers" },
          { id: "s30-6", term: "rules-based trading", hint: "Systematic exchange approach" },
          { id: "s30-7", term: "risk management protocols", hint: "Loss prevention rules" }
        ]
      },
      {
        id: "31",
        story: "Sophia explored socially responsible investing. She researched environmental impact metrics and corporate governance standards. Understanding ESG criteria shaped her investment decisions. She balanced ethical considerations with financial performance goals.",
        financialTerms: [
          { id: "s31-1", term: "socially responsible investing", hint: "Investment approach considering social impact" },
          { id: "s31-2", term: "environmental impact metrics", hint: "Measures of environmental effects" },
          { id: "s31-3", term: "corporate governance standards", hint: "Rules for company management" },
          { id: "s31-4", term: "ESG criteria", hint: "Environmental, social, and governance factors" },
          { id: "s31-5", term: "investment decisions", hint: "Choices about where to invest money" },
          { id: "s31-6", term: "ethical considerations", hint: "Moral factors in decision making" },
          { id: "s31-7", term: "financial performance goals", hint: "Targeted investment returns" }
        ]
       
      },
      {
        id: "32",
        story: "Jackson studied fixed income derivatives. He analyzed interest rate swaps and bond futures. Understanding duration and convexity improved his risk management. He developed hedging strategies for interest rate exposure.",
        financialTerms: [
          { id: "s32-1", term: "fixed income derivatives", hint: "Financial contracts based on debt instruments" },
          { id: "s32-2", term: "interest rate swaps", hint: "Agreements to exchange interest payments" },
          { id: "s32-3", term: "bond futures", hint: "Contracts for future bond transactions" },
          { id: "s32-4", term: "duration", hint: "Measure of price sensitivity to interest rates" },
          { id: "s32-5", term: "convexity", hint: "Rate of change of duration" },
          { id: "s32-6", term: "risk management", hint: "Process of identifying and controlling risks" },
          { id: "s32-7", term: "hedging strategies", hint: "Methods to reduce financial risk" },
          { id: "s32-8", term: "interest rate exposure", hint: "Vulnerability to rate changes" }
        ]
      },
      {
        id: "33",
        story: "Isabella explored peer-to-peer lending platforms. She analyzed credit risk assessment models and interest rate determination. Understanding default statistics improved her loan selection. She developed a diversified lending portfolio across risk categories.",
        financialTerms: [
          { id: "s33-1", term: "peer-to-peer lending", hint: "Direct borrower financing" },
          { id: "s33-2", term: "credit risk", hint: "Default possibility assessment" },
          { id: "s33-3", term: "interest rate determination", hint: "Return percentage setting" },
          { id: "s33-4", term: "default statistics", hint: "Non-payment probability data" },
          { id: "s33-5", term: "loan selection", hint: "Debt opportunity choosing" },
          { id: "s33-6", term: "risk categories", hint: "Danger classification groups" },
          { id: "s33-7", term: "diversified lending portfolio", hint: "Spread-out loan investments" }
        ]
      },
      {
        id: "34",
        story: "Lucas studied factor-based investing approaches. He analyzed value and momentum factors across markets. Understanding factor premiums improved his portfolio construction. He developed a multi-factor model with adaptive weightings.",
        financialTerms: [
          { id: "s34-1", term: "factor-based investing", hint: "Characteristic-driven approach" },
          { id: "s34-2", term: "value factors", hint: "Worth-related characteristics" },
          { id: "s34-3", term: "momentum factors", hint: "Trend-following indicators" },
          { id: "s34-4", term: "factor premiums", hint: "Characteristic-based returns" },
          { id: "s34-5", term: "portfolio construction", hint: "Investment collection building" },
          { id: "s34-6", term: "multi-factor model", hint: "Combined characteristic system" },
          { id: "s34-7", term: "adaptive weightings", hint: "Dynamic allocation adjustments" }
        ]
      },
      {
        id: "35",
        story: "Mia explored alternative investment options. She researched private equity funds and venture capital opportunities. Understanding illiquidity premiums shaped her allocation decisions. She balanced traditional and alternative investments for optimal diversification.",
        financialTerms: [
          { id: "s35-1", term: "alternative investment options", hint: "Non-traditional investment choices" },
          { id: "s35-2", term: "private equity funds", hint: "Investment pools buying private companies" },
          { id: "s35-3", term: "venture capital opportunities", hint: "Startup funding investments" },
          { id: "s35-4", term: "illiquidity premiums", hint: "Extra returns for holding non-tradable assets" },
          { id: "s35-5", term: "allocation decisions", hint: "Investment distribution choices" },
          { id: "s35-6", term: "traditional investments", hint: "Conventional investment types" },
          { id: "s35-7", term: "alternative investments", hint: "Non-conventional investment assets" },
          { id: "s35-8", term: "optimal diversification", hint: "Best risk-spreading strategy" }
        ]
      },
      {
        id: "36",
        story: "Ethan studied behavioral economics principles. He analyzed cognitive biases and market anomalies. Understanding investor psychology improved his contrarian approach. He developed strategies to capitalize on market inefficiencies.",
        financialTerms: [
          { id: "s36-1", term: "behavioral economics", hint: "Psychological financial study" },
          { id: "s36-2", term: "cognitive biases", hint: "Mental judgment errors" },
          { id: "s36-3", term: "market anomalies", hint: "Pricing irregularities" },
          { id: "s36-4", term: "investor psychology", hint: "Trader mental patterns" },
          { id: "s36-5", term: "contrarian approach", hint: "Opposite-consensus strategy" },
          { id: "s36-6", term: "market inefficiencies", hint: "Pricing imperfections" }
        ]
      },
      {
        id: "37",
        story: "Amelia explored global macro investing strategies. She analyzed economic indicators and geopolitical trends. Understanding currency dynamics improved her international allocations. She developed a top-down investment approach with regional rotations.",
        financialTerms: [
          { id: "s37-1", term: "global macro investing", hint: "Worldwide economic strategy" },
          { id: "s37-2", term: "economic indicators", hint: "Financial health measurements" },
          { id: "s37-3", term: "geopolitical trends", hint: "Political influence patterns" },
          { id: "s37-4", term: "currency dynamics", hint: "Money value relationships" },
          { id: "s37-5", term: "international allocations", hint: "Cross-border investments" },
          { id: "s37-6", term: "top-down approach", hint: "Broad-to-specific analysis" },
          { id: "s37-7", term: "regional rotations", hint: "Geographic investment shifts" }
        ]
      },
      {
        id: "38",
        story: "Emma studied business succession planning. She analyzed buy-sell agreements and management buyouts. Understanding business valuation methods improved her exit strategy. She learned about family limited partnerships and installment sales.",
        financialTerms: [
          { id: "s38-1", term: "business succession planning", hint: "Process of planning leadership transition in a business" },
          { id: "s38-2", term: "buy-sell agreements", hint: "Contracts governing business ownership transfer" },
          { id: "s38-3", term: "management buyouts", hint: "Purchase of company by its managers" },
          { id: "s38-4", term: "business valuation methods", hint: "Techniques for determining business worth" },
          { id: "s38-5", term: "exit strategy", hint: "Plan for selling or transferring ownership" },
          { id: "s38-6", term: "family limited partnerships", hint: "Business structure for family ownership" },
          { id: "s38-7", term: "installment sales", hint: "Selling business with payments over time" }
        ],
        
      },
      {
        id: "39",
        story: "Charlotte explored quantitative portfolio management. She studied factor exposures and risk decomposition. Understanding optimization algorithms improved her portfolio efficiency. She developed systematic rebalancing protocols based on drift thresholds.",
    financialTerms: [
      { id: "s39-1", term: "quantitative portfolio management", hint: "Mathematical approach to managing investments" },
      { id: "s39-2", term: "factor exposures", hint: "Investment characteristics affecting returns" },
      { id: "s39-3", term: "risk decomposition", hint: "Breaking down sources of investment risk" },
      { id: "s39-4", term: "optimization algorithms", hint: "Mathematical methods for portfolio improvement" },
      { id: "s39-5", term: "portfolio efficiency", hint: "Maximizing returns for given risk level" },
      { id: "s39-6", term: "systematic rebalancing protocols", hint: "Regular portfolio adjustment rules" },
      { id: "s39-7", term: "drift thresholds", hint: "Limits triggering portfolio rebalancing" }
    ],
     },
      {
        id: "40",
        story: "Henry studied merger arbitrage strategies. He analyzed acquisition premiums and regulatory approval probabilities. Understanding deal structures improved his risk assessment. He developed position sizing models based on expected outcomes.",
        financialTerms: [
          { id: "s40-1", term: "merger arbitrage strategies", hint: "Trading tactics around corporate combinations" },
          { id: "s40-2", term: "acquisition premiums", hint: "Extra amount paid above market price in takeovers" },
          { id: "s40-3", term: "regulatory approval probabilities", hint: "Likelihood of government permission for deals" },
          { id: "s40-4", term: "deal structures", hint: "Framework of merger and acquisition terms" },
          { id: "s40-5", term: "risk assessment", hint: "Evaluation of potential losses" },
          { id: "s40-6", term: "position sizing models", hint: "Methods for determining investment amounts" },
          { id: "s40-7", term: "expected outcomes", hint: "Anticipated results of investment decisions" }
        ]
      },
      {
        id: "41",
        story: "Evelyn explored commodity trading strategies. She analyzed futures curves and seasonal patterns. Understanding roll yield improved her commodity index investments. She developed sector rotation approaches based on economic cycles.",
        financialTerms: [
          { id: "s41-1", term: "commodity trading", hint: "Raw materials exchange" },
          { id: "s41-2", term: "futures curves", hint: "Price-time relationships" },
          { id: "s41-3", term: "seasonal patterns", hint: "Recurring time cycles" },
          { id: "s41-4", term: "roll yield", hint: "Contract replacement return" },
          { id: "s41-5", term: "commodity index investments", hint: "Materials price benchmark" },
          { id: "s41-6", term: "sector rotation", hint: "Industry focus shifting" },
          { id: "s41-7", term: "economic cycles", hint: "Business activity patterns" }
        ]
      },
      {
        id: "42",
        story: "Alexander studied high-frequency trading systems. He analyzed market microstructure and order book dynamics. Understanding latency optimization improved his execution algorithms. He developed sophisticated statistical arbitrage strategies.",
        financialTerms: [
          { id: "s42-1", term: "high-frequency trading", hint: "Rapid transaction systems" },
          { id: "s42-2", term: "market microstructure", hint: "Exchange mechanism details" },
          { id: "s42-3", term: "order book", hint: "Transaction request record" },
          { id: "s42-4", term: "latency optimization", hint: "Delay minimization process" },
          { id: "s42-5", term: "execution algorithms", hint: "Trade completion formulas" },
          { id: "s42-6", term: "statistical arbitrage", hint: "Mathematical price exploitation" }
        ]
      },
      {
        id: "43",
        story: "Abigail explored distressed debt investing. She analyzed bankruptcy procedures and debt restructuring processes. Understanding recovery rates improved her valuation models. She developed strategies for investing in troubled company securities.",
        financialTerms: [
          { id: "s43-1", term: "distressed debt", hint: "Troubled company obligations" },
          { id: "s43-2", term: "bankruptcy procedures", hint: "Insolvency legal processes" },
          { id: "s43-3", term: "debt restructuring", hint: "Obligation reorganization" },
          { id: "s43-4", term: "recovery rates", hint: "Repayment percentage expectations" },
          { id: "s43-5", term: "valuation models", hint: "Worth calculation systems" },
          { id: "s43-6", term: "troubled company securities", hint: "Distressed business investments" }
        ]
      },
      {
        id: "44",
        story: "Daniel studied inflation-protected investment strategies. He analyzed TIPS and inflation-linked bonds. Understanding real yield calculations improved his portfolio protection. He developed asset allocation models for inflationary environments.",
        financialTerms: [
          { id: "s44-1", term: "inflation-protected investment", hint: "Strategies to preserve value during rising prices" },
          { id: "s44-2", term: "TIPS", hint: "Treasury Inflation-Protected Securities" },
          { id: "s44-3", term: "inflation-linked bonds", hint: "Debt securities adjusted for inflation" },
          { id: "s44-4", term: "real yield", hint: "Return adjusted for inflation" },
          { id: "s44-5", term: "portfolio protection", hint: "Safeguarding investment value" },
          { id: "s44-6", term: "asset allocation", hint: "Distribution of investments" },
          { id: "s44-7", term: "inflationary environments", hint: "Economic conditions with rising prices" }
        ],
       
      },
      {
        id: "45",
        story: "Scarlett explored convertible bond arbitrage. She analyzed conversion premiums and implied volatility. Understanding credit spreads improved her relative value analysis. She developed delta-neutral strategies with positive carry.",
        financialTerms: [
          { id: "s45-1", term: "convertible bond arbitrage", hint: "Exchangeable security exploitation" },
          { id: "s45-2", term: "conversion premiums", hint: "Exchange price differences" },
          { id: "s45-3", term: "implied volatility", hint: "Expected price movement" },
          { id: "s45-4", term: "credit spreads", hint: "Risk premium differences" },
          { id: "s45-5", term: "relative value", hint: "Comparative worth analysis" },
          { id: "s45-6", term: "delta-neutral", hint: "Price-movement balanced" },
          { id: "s45-7", term: "positive carry", hint: "Earning more than borrowing cost" }
        ]
      
      },
      {
        id: "46",
        story: "Joseph studied algorithmic trading development. He analyzed backtesting methodologies and optimization techniques. Understanding overfitting risks improved his model validation. He developed robust trading systems.",
        financialTerms: [
          { id: "s46-1", term: "algorithmic trading", hint: "Formula-based exchanges" },
          { id: "s46-2", term: "backtesting", hint: "Historical performance simulation" },
          { id: "s46-3", term: "optimization techniques", hint: "Improvement methodologies" },
          { id: "s46-4", term: "overfitting", hint: "Excessive customization problem" },
          { id: "s46-5", term: "model validation", hint: "System verification process" },
          { id: "s46-6", term: "trading systems", hint: "Automated trading platforms" },
          ]
      },
      {
        id: "47",
        story: "Victoria explored emerging market investments. She analyzed country risk premiums and political stability factors. Understanding currency hedging improved her international portfolio management. She developed allocation strategies across developing economies.",
        financialTerms: [
          { id: "s47-0", term: "allocation strategies", hint: "Investment distribution methods" },
          { id: "s47-1", term: "emerging market", hint: "Developing economy investments" },
          { id: "s47-2", term: "country risk", hint: "Nation-specific dangers" },
          { id: "s47-3", term: "political stability", hint: "Governmental consistency" },
          { id: "s47-4", term: "currency hedging", hint: "Exchange rate protection" },
          { id: "s47-5", term: "international portfolio", hint: "Global investment collection" },
          { id: "s47-6", term: "developing economies", hint: "Growing financial systems" }
        ]
      },
      {
        id: "48",
        story: "Samuel studied credit default swaps. He analyzed counterparty risks and default probabilities. Understanding recovery assumptions improved his pricing models. He developed strategies for hedging bond portfolios against default risk.",
        financialTerms: [
          { id: "s48-1", term: "credit default swaps", hint: "Financial contracts that protect against bond defaults" },
          { id: "s48-2", term: "counterparty risks", hint: "Risk that a trading partner may not fulfill obligations" },
          { id: "s48-3", term: "default probabilities", hint: "Likelihood of failing to repay debt" },
          { id: "s48-4", term: "recovery assumptions", hint: "Estimated value recovered after default" },
          { id: "s48-5", term: "pricing models", hint: "Tools for determining financial instrument values" },
          { id: "s48-6", term: "strategies", hint: "Planned approaches to achieve financial goals" },
          { id: "s48-7", term: "bond portfolios", hint: "Collections of debt investments" },
          { id: "s48-8", term: "default risk", hint: "Possibility of bond payment failure" }
        ]
      },
      {
        id: "49",
        story: "Elizabeth explored dividend growth investing. She analyzed payout ratios and earnings stability. Understanding dividend reinvestment improved her compounding strategy. She developed a portfolio of consistent dividend growers for retirement income.",
        financialTerms: [
          { id: "s49-1", term: "dividend growth investing", hint: "Strategy focusing on stocks that increase dividends" },
          { id: "s49-2", term: "payout ratios", hint: "Percentage of earnings paid as dividends" },
          { id: "s49-3", term: "earnings stability", hint: "Consistency in company profits" },
          { id: "s49-4", term: "dividend reinvestment", hint: "Using dividends to buy more shares" },
          { id: "s49-5", term: "compounding strategy", hint: "Method to grow wealth exponentially" },
          { id: "s49-6", term: "portfolio", hint: "Collection of investments" },
          { id: "s49-7", term: "dividend growers", hint: "Companies that regularly increase dividends" },
          { id: "s49-8", term: "retirement income", hint: "Money for post-work life" }
        ]
      },
      {
        id: "50",
        story: "Matthew studied risk parity portfolio construction. He analyzed asset class correlations and volatility targeting. Understanding leverage effects improved his allocation methodology. He developed all-weather portfolios with balanced risk contributions.",
        financialTerms: [
          { id: "s50-1", term: "risk parity portfolio construction", hint: "Investment strategy balancing risk across asset classes" },
          { id: "s50-2", term: "asset class correlations", hint: "Relationships between different investment types" },
          { id: "s50-3", term: "volatility targeting", hint: "Managing portfolio risk levels" },
          { id: "s50-4", term: "leverage effects", hint: "Impact of borrowed money on investments" },
          { id: "s50-5", term: "allocation methodology", hint: "System for distributing investment funds" },
          { id: "s50-6", term: "all-weather portfolios", hint: "Investments designed to perform in various conditions" },
          { id: "s50-7", term: "balanced risk", hint: "Equal distribution of investment risk" },
          { id: "s50-8", term: "risk contributions", hint: "Amount of risk from each investment" }
        ]
      },
      {
        id: "51",
        story: "Chloe explored sustainable investing principles. She analyzed environmental impact reports and social responsibility metrics. Understanding green bonds improved her ethical portfolio construction. She developed screening criteria for ESG-compliant investments.",
        financialTerms: [
          { id: "s51-1", term: "sustainable investing principles", hint: "Guidelines for responsible investment" },
          { id: "s51-2", term: "environmental impact reports", hint: "Documents assessing ecological effects" },
          { id: "s51-3", term: "social responsibility metrics", hint: "Measures of community impact" },
          { id: "s51-4", term: "green bonds", hint: "Environmental project funding" },
          { id: "s51-5", term: "ethical portfolio construction", hint: "Responsible investment building" },
          { id: "s51-6", term: "screening criteria", hint: "Investment selection standards" },
          { id: "s51-7", term: "ESG-compliant investments", hint: "Environmental, Social, Governance aligned assets" }
        ]
      },
      {
        id: "52",
        story: "Andrew studied fixed income analytics. He analyzed yield curves and interest rate forecasts. Understanding bond duration improved his portfolio sensitivity management. He developed strategies for navigating changing rate environments.",
        financialTerms: [
          { id: "s52-1", term: "fixed income analytics", hint: "Debt security analysis" },
          { id: "s52-2", term: "yield curves", hint: "Interest rate visualizations" },
          { id: "s52-3", term: "interest rate forecasts", hint: "Future percentage predictions" },
          { id: "s52-4", term: "bond duration", hint: "Price sensitivity measurement" },
          { id: "s52-5", term: "portfolio sensitivity", hint: "Investment reaction potential" },
          { id: "s52-6", term: "rate environments", hint: "Interest percentage conditions" }
        ]
      },
      {
        id: "53",
        story: "Zoe studied equity valuation methodologies. She analyzed discounted cash flow models and comparative multiples. Understanding terminal value calculations improved her intrinsic value estimates. She developed comprehensive valuation frameworks for stock analysis.",
        financialTerms: [
          { id: "s53-1", term: "equity valuation", hint: "Process of determining stock worth" },
          { id: "s53-2", term: "discounted cash flow", hint: "Future value calculation method" },
          { id: "s53-3", term: "comparative multiples", hint: "Relative valuation metrics" },
          { id: "s53-4", term: "terminal value", hint: "Long-term business value" },
          { id: "s53-5", term: "intrinsic value", hint: "True worth of an asset" },
          { id: "s53-6", term: "valuation frameworks", hint: "Methods for determining value" },
          { id: "s53-7", term: "stock analysis", hint: "Evaluation of equity investments" }
        ]
      },
      {
        id: "54",
        story: "Christopher explored currency carry trade strategies. He analyzed interest rate differentials and central bank policies. Understanding currency volatility improved his risk management approach. He developed systematic methods for exploiting yield advantages across countries.",
        financialTerms: [
          { id: "s54-1", term: "currency carry trade", hint: "Interest differential exploitation" },
          { id: "s54-2", term: "interest rate differentials", hint: "Yield percentage gaps" },
          { id: "s54-3", term: "central bank policies", hint: "Monetary authority decisions" },
          { id: "s54-4", term: "currency volatility", hint: "Exchange rate fluctuation" },
          { id: "s54-5", term: "risk management approach", hint: "Danger handling methodology" },
          { id: "s54-6", term: "yield advantages", hint: "Return benefit opportunities" }
        ]
      },
      {
        id: "55",
        story: "Phoebe studied small-cap investing strategies. She analyzed growth potential and liquidity constraints. Understanding size factor premiums improved her equity allocation decisions. She developed comprehensive frameworks for small company research.",
        financialTerms: [
          { id: "s55-1", term: "small-cap investing", hint: "Lesser-sized company allocation" },
          { id: "s55-2", term: "growth potential", hint: "Expansion possibility assessment" },
          { id: "s55-3", term: "liquidity constraints", hint: "Trading limitation challenges" },
          { id: "s55-4", term: "size factor premiums", hint: "Dimension-based return advantages" },
          { id: "s55-5", term: "equity allocation", hint: "Stock investment distribution" },
          { id: "s55-6", term: "small company research", hint: "Lesser business investigation" }
        ]
      },
      {
        id: "56",
        story: "Jasper explored international diversification strategies. He analyzed country-specific risks and currency exposures. Understanding global sector allocations improved his portfolio construction. He developed comprehensive frameworks for global investment selection.",
        financialTerms: [
          { id: "s56-1", term: "international diversification", hint: "Global risk spreading" },
          { id: "s56-2", term: "country-specific risks", hint: "Nation-particular dangers" },
          { id: "s56-3", term: "currency exposures", hint: "Exchange rate vulnerabilities" },
          { id: "s56-4", term: "global sector allocations", hint: "Worldwide industry distributions" },
          { id: "s56-5", term: "portfolio construction", hint: "Investment collection building" },
          { id: "s56-6", term: "global investment selection", hint: "Worldwide opportunity choosing" }
        ]
      },
      {
        id: "57",
        story: "Daisy studied bond ladder strategies. She analyzed yield curve positioning and reinvestment approaches. Understanding interest rate risk management improved her fixed income portfolio. She learned about duration matching and maturity diversification.",
        financialTerms: [
          { id: "s57-1", term: "bond ladder strategies", hint: "Staggered bond investment approach" },
          { id: "s57-2", term: "yield curve positioning", hint: "Strategic bond placement" },
          { id: "s57-3", term: "reinvestment approaches", hint: "Methods for redeploying funds" },
          { id: "s57-4", term: "interest rate risk management", hint: "Rate fluctuation protection" },
          { id: "s57-5", term: "fixed income portfolio", hint: "Bond investment collection" },
          { id: "s57-6", term: "duration matching", hint: "Time-based risk alignment" },
          { id: "s57-7", term: "maturity diversification", hint: "Varied bond expiration dates" }
        ]
        
      },
      {
        id: "58",
        story: "Nathan explored municipal bond investing. He researched tax-exempt income opportunities and credit quality assessments. Understanding state-specific advantages helped his tax planning. He developed a strategy for balancing yield and safety.",
        financialTerms: [
          { id: "s58-1", term: "municipal bonds", hint: "Debt securities issued by local governments" },
          { id: "s58-2", term: "tax-exempt income", hint: "Earnings not subject to certain taxes" },
          { id: "s58-3", term: "credit quality", hint: "Measurement of borrower's ability to repay debt" },
          { id: "s58-4", term: "tax planning", hint: "Strategies to minimize tax liability" },
          { id: "s58-5", term: "yield", hint: "Return on investment expressed as percentage" },
          { id: "s58-6", term: "safety", hint: "Protection against investment loss" },
          { id: "s58-7", term: "balancing", hint: "Managing trade-offs between different factors" }
        ]
      },
      {
        id: "59",
        story: "Leila studied retirement withdrawal strategies. She analyzed sequence of returns risk and sustainable withdrawal rates. Understanding longevity planning improved her retirement income strategy. She learned about bucket approaches and dynamic spending adjustments.",
        financialTerms: [
          { id: "s59-1", term: "retirement withdrawal strategies", hint: "Methods for taking money from retirement accounts" },
          { id: "s59-2", term: "sequence of returns risk", hint: "Impact of investment timing on retirement savings" },
          { id: "s59-3", term: "sustainable withdrawal rates", hint: "Safe percentage of retirement savings to withdraw" },
          { id: "s59-4", term: "longevity planning", hint: "Preparing for extended retirement lifespan" },
          { id: "s59-5", term: "retirement income strategy", hint: "Plan for generating retirement cash flow" },
          { id: "s59-6", term: "bucket approaches", hint: "Segmented retirement asset allocation" },
          { id: "s59-7", term: "dynamic spending adjustments", hint: "Flexible retirement withdrawal modifications" }
        ]
      },
      {
        id: "60",
        story: "Victor explored factor investing principles. He studied value and momentum strategies. Understanding smart beta approaches improved his portfolio construction. He learned about factor tilting and multi-factor optimization.",
        financialTerms: [
          { id: "s60-1", term: "factor investing", hint: "Targeting specific investment characteristics" },
          { id: "s60-2", term: "value strategies", hint: "Investing in underpriced assets" },
          { id: "s60-3", term: "momentum strategies", hint: "Buying assets with positive price trends" },
          { id: "s60-4", term: "smart beta", hint: "Rules-based investment approach" },
          { id: "s60-5", term: "factor tilting", hint: "Overweighting specific investment characteristics" },
          { id: "s60-6", term: "multi-factor optimization", hint: "Balancing multiple investment characteristics" }
        ]
      },
      {
        id: "61",
        story: "Sophia studied behavioral economics principles. She analyzed cognitive biases and emotional investing patterns. Understanding prospect theory improved her decision-making process. She developed strategies to overcome loss aversion and recency bias.",
        financialTerms: [
          { id: "s61-1", term: "behavioral economics", hint: "Study of psychological influences on economic decisions" },
          { id: "s61-2", term: "cognitive biases", hint: "Systematic errors in thinking" },
          { id: "s61-3", term: "emotional investing", hint: "Making financial decisions based on feelings" },
          { id: "s61-4", term: "prospect theory", hint: "Framework explaining irrational decision-making" },
          { id: "s61-5", term: "loss aversion", hint: "Tendency to prefer avoiding losses over acquiring gains" },
          { id: "s61-6", term: "recency bias", hint: "Overweighting recent events in decisions" }
        ]
      },
      {
        id: "62",
        story: "Marcus explored alternative investment vehicles. He researched private equity and venture capital opportunities. Understanding illiquidity premiums shaped his portfolio allocation. He learned about valuation methodologies and exit strategies.",
        financialTerms: [
          { id: "s62-1", term: "alternative investments", hint: "Non-traditional asset classes" },
          { id: "s62-2", term: "private equity", hint: "Ownership in non-public companies" },
          { id: "s62-3", term: "venture capital", hint: "Funding for early-stage companies" },
          { id: "s62-4", term: "illiquidity premium", hint: "Extra return for investments that cannot be easily sold" },
          { id: "s62-5", term: "valuation methodologies", hint: "Techniques for determining asset worth" },
          { id: "s62-6", term: "portfolio allocation", hint: "Distribution of investments across different assets" },
          { id: "s62-7", term: "exit strategies", hint: "Plans for ending investment positions" }
        ]
      },
      {
        id: "63",
        story: "Amelia studied tax-loss harvesting techniques. She analyzed wash sale rules and capital gains offsetting. Understanding tax-efficient investing improved her after-tax returns. She developed a systematic approach to tax-aware portfolio management.",
        financialTerms: [
          { id: "s63-1", term: "tax-loss harvesting", hint: "Selling losing investments to offset gains" },
          { id: "s63-2", term: "wash sale rules", hint: "Regulations preventing tax benefits from quickly repurchasing" },
          { id: "s63-3", term: "capital gains offsetting", hint: "Using losses to reduce taxable investment profits" },
          { id: "s63-4", term: "tax-efficient investing", hint: "Strategies minimizing investment taxation" },
          { id: "s63-5", term: "after-tax returns", hint: "Investment performance after tax payments" },
          { id: "s63-6", term: "tax-aware portfolio", hint: "Investments managed with tax implications in mind" }
        ]
      },
      {
        id: "64",
        story: "Benjamin explored real estate investment trusts. He analyzed different REIT sectors and dividend yields. Understanding REIT taxation improved his income strategy. He learned about equity, mortgage, and hybrid REIT structures.",
        financialTerms: [
          { id: "s64-1", term: "real estate investment trusts", hint: "Companies owning income-producing real estate" },
          { id: "s64-2", term: "REIT sectors", hint: "Categories of property specialization" },
          { id: "s64-3", term: "dividend yields", hint: "Annual dividend income as percentage of price" },
          { id: "s64-4", term: "REIT taxation", hint: "Special tax rules for real estate companies" },
          { id: "s64-5", term: "income strategy", hint: "Plan for generating investment returns" },
          { id: "s64-6", term: "equity REIT", hint: "Trust owning and managing properties" },
          { id: "s64-7", term: "mortgage REIT", hint: "Trust financing real estate" },
          { id: "s64-8", term: "hybrid REIT structures", hint: "Combination of property ownership and financing" }
        ]
      },
      {
        id: "65",
        story: "Isabella studied socially responsible investing criteria. She researched environmental, social, and governance factors. Understanding impact measurement improved her ethical portfolio construction. She learned about screening methodologies and shareholder advocacy.",
        financialTerms: [
          { id: "s65-1", term: "socially responsible investing", hint: "Considering ethics in investment decisions" },
          { id: "s65-2", term: "environmental factors", hint: "Ecological considerations in investing" },
          { id: "s65-3", term: "governance factors", hint: "Company management quality assessment" },
          { id: "s65-4", term: "impact measurement", hint: "Quantifying social and environmental effects" },
          { id: "s65-5", term: "screening methodologies", hint: "Techniques for filtering investments" },
          { id: "s65-7", term: "ethical portfolio construction", hint: "Building investment portfolios based on moral principles" }
        ]
      },
      {
        id: "66",
        story: "Noah explored options trading strategies. He studied covered calls and protective puts. Understanding option Greeks improved his risk management approach. He learned about vertical spreads and iron condors for defined-risk positions.",
        financialTerms: [
          { id: "s66-1", term: "options trading", hint: "Buying and selling contract rights" },
          { id: "s66-2", term: "covered calls", hint: "Selling call options against owned stock" },
          { id: "s66-3", term: "protective puts", hint: "Buying put options to protect investments" },
          { id: "s66-4", term: "option Greeks", hint: "Risk measurements for options contracts" },
          { id: "s66-5", term: "vertical spreads", hint: "Option strategy using same expiration dates" },
          { id: "s66-6", term: "iron condors", hint: "Option strategy with defined profit and loss range" },
          { id: "s66-7", term: "risk management", hint: "Process of controlling potential losses" },
          { id: "s66-8", term: "defined-risk positions", hint: "Trades with known maximum loss potential" }
        ]
      },
      {
        id: "67",
        story: "Charlotte studied fixed income derivatives. She analyzed interest rate swaps and bond futures. Understanding convexity hedging improved her portfolio protection. She learned about yield curve strategies and basis trading.",
        financialTerms: [
          { id: "s67-1", term: "fixed income derivatives", hint: "Financial instruments based on debt securities" },
          { id: "s67-2", term: "interest rate swaps", hint: "Agreements to exchange interest payments" },
          { id: "s67-3", term: "bond futures", hint: "Contracts for future bond transactions" },
          { id: "s67-4", term: "convexity hedging", hint: "Strategy to protect against rate changes" },
          { id: "s67-5", term: "portfolio protection", hint: "Safeguarding investment holdings" },
          { id: "s67-6", term: "yield curve strategies", hint: "Interest rate trading approaches" },
          { id: "s67-7", term: "basis trading", hint: "Exploiting price differences" }
        ]
      },
      {
        id: "68",
        story: "Ethan explored quantitative portfolio construction. He studied factor exposures and risk decomposition. Understanding optimization constraints improved his portfolio efficiency. He learned about rebalancing methodologies and tracking error management.",
        financialTerms: [
          { id: "s68-1", term: "quantitative portfolio construction", hint: "Mathematical approach to building investment portfolios" },
          { id: "s68-2", term: "factor exposures", hint: "Investment sensitivity to market factors" },
          { id: "s68-3", term: "risk decomposition", hint: "Breaking down portfolio risks into components" },
          { id: "s68-4", term: "optimization constraints", hint: "Limits in portfolio optimization process" },
          { id: "s68-5", term: "portfolio efficiency", hint: "Optimal risk-return balance in investments" },
          { id: "s68-6", term: "rebalancing methodologies", hint: "Techniques for adjusting portfolio allocations" },
          { id: "s68-7", term: "tracking error management", hint: "Controlling deviation from benchmark performance" }
        ]
      },
      {
        id: "69",
        story: "Ava studied global macro investing. She analyzed economic indicators and central bank policies. Understanding geopolitical risks improved her cross-asset allocation. She learned about currency hedging and international diversification strategies.",
        financialTerms: [
          { id: "s69-1", term: "global macro investing", hint: "Investment strategy based on global economic trends" },
          { id: "s69-2", term: "economic indicators", hint: "Statistics showing economic conditions" },
          { id: "s69-3", term: "central bank policies", hint: "Monetary decisions by national banks" },
          { id: "s69-4", term: "geopolitical risks", hint: "Political factors affecting investments" },
          { id: "s69-5", term: "cross-asset allocation", hint: "Distribution across different investments" },
          { id: "s69-6", term: "currency hedging", hint: "Protection against currency fluctuations" },
          { id: "s69-7", term: "international diversification", hint: "Global investment spreading" },
           
        ],
         
      },
      {
        id: "70",
        story: "Lucas explored structured product investments. He analyzed principal protection features and yield enhancement strategies. Understanding embedded derivatives improved his risk assessment. He learned about autocallable notes and barrier options.",
        financialTerms: [
          { id: "s70-1", term: "structured products", hint: "Packaged investment strategies with specific features" },
          { id: "s70-2", term: "principal protection", hint: "Features safeguarding original investment amount" },
          { id: "s70-3", term: "yield enhancement", hint: "Strategies increasing investment returns" },
          { id: "s70-4", term: "embedded derivatives", hint: "Built-in financial contracts within products" },
          { id: "s70-5", term: "autocallable notes", hint: "Investments that may automatically redeem early" },
          { id: "s70-6", term: "barrier options", hint: "Contracts activated by price threshold crossing" },
          { id: "s70-7", term: "risk assessment", hint: "Evaluation of potential investment dangers" }
        ]
      },
      {
        id: "71",
        story: "Mia studied retirement income planning. She analyzed systematic withdrawal strategies and annuitization options. Understanding sequence risk improved her distribution planning. She learned about bucket strategies and dynamic spending rules.",
        financialTerms: [
          { id: "s71-1", term: "retirement income", hint: "Money received during non-working years" },
          { id: "s71-2", term: "systematic withdrawal", hint: "Regular planned retirement account distributions" },
          { id: "s71-3", term: "annuitization", hint: "Converting assets into guaranteed income streams" },
          { id: "s71-4", term: "sequence risk", hint: "Danger from investment return timing" },
          { id: "s71-5", term: "distribution planning", hint: "Strategies for withdrawing retirement funds" },
          { id: "s71-6", term: "bucket strategies", hint: "Segmented retirement asset allocation" },
          { id: "s71-7", term: "dynamic spending rules", hint: "Flexible retirement withdrawal guidelines" },
        ]
      },
      {
        id: "72",
        story: "Jacob explored tactical asset allocation. He studied business cycle indicators and sector rotation strategies. Understanding relative strength analysis improved his market timing. He learned about momentum factors and mean reversion principles.",
        financialTerms: [
          { id: "s72-1", term: "tactical asset allocation", hint: "Dynamic investment portfolio adjustment strategy" },
          { id: "s72-2", term: "business cycle indicators", hint: "Economic activity measurement metrics" },
          { id: "s72-3", term: "sector rotation strategies", hint: "Moving investments between different market sectors" },
          { id: "s72-4", term: "relative strength analysis", hint: "Comparing performance between investments" },
          { id: "s72-5", term: "market timing", hint: "Strategy of entering and exiting markets" },
          { id: "s72-6", term: "momentum factors", hint: "Indicators of price movement strength" },
          { id: "s72-7", term: "mean reversion principles", hint: "Theory that prices return to average" }
        ]
      },
      {
        id: "73",
        story: "Emma studied financial planning for business owners. She analyzed succession planning and key person insurance. Understanding business valuation methods improved her exit strategy. She learned about buy-sell agreements and equity compensation structures.",
        financialTerms: [
          { id: "s73-1", term: "succession planning", hint: "Preparing for business ownership transfer" },
          { id: "s73-2", term: "key person insurance", hint: "Coverage protecting against loss of essential employees" },
          { id: "s73-3", term: "business valuation", hint: "Process of determining company worth" },
          { id: "s73-4", term: "exit strategy", hint: "Plan for selling business ownership" },
          { id: "s73-5", term: "buy-sell agreements", hint: "Contracts governing business interest transfers" },
          { id: "s73-6", term: "equity compensation", hint: "Payment using company ownership shares" }
        ]
      },
      {
        id: "74",
        story: "Alexander studied advanced tax planning strategies. He analyzed trust structures and charitable giving techniques. Understanding estate tax minimization improved his wealth transfer planning. He learned about dynasty trusts and family limited partnerships.",
        financialTerms: [
          { id: "s74-1", term: "tax planning", hint: "Strategies to minimize tax liability" },
          { id: "s74-2", term: "trust structures", hint: "Legal arrangements for asset management" },
          { id: "s74-3", term: "charitable giving", hint: "Donating assets to nonprofit organizations" },
          { id: "s74-4", term: "estate tax", hint: "Levy on transferred assets after death" },
          { id: "s74-5", term: "wealth transfer", hint: "Passing assets to next generation" },
          { id: "s74-6", term: "dynasty trusts", hint: "Long-term wealth preservation vehicles" }
        ]
      },
      {
        id: "75",
        story: "Olivia explored healthcare financial planning. She analyzed Medicare options and long-term care insurance. Understanding health savings accounts improved her medical expense strategy. She learned about healthcare proxies and advance directives.",
        financialTerms: [
          { id: "s75-1", term: "healthcare planning", hint: "Preparing for medical expenses" },
          { id: "s75-2", term: "Medicare", hint: "Government health insurance for seniors" },
          { id: "s75-3", term: "long-term care insurance", hint: "Coverage for extended medical assistance" },
          { id: "s75-4", term: "health savings accounts", hint: "Tax-advantaged medical expense funds" },
          { id: "s75-5", term: "healthcare proxies", hint: "Legal medical decision representatives" },
          { id: "s75-6", term: "advance directives", hint: "Legal documents for healthcare wishes" }
        ]
      },
      {
        id: "76",
        story: "William studied algorithmic trading systems. He analyzed execution algorithms and market microstructure. Understanding latency issues improved his high-frequency strategies. He learned about order routing and dark pool liquidity.",
        financialTerms: [
          { id: "s76-1", term: "algorithmic trading", hint: "Computer-automated investment execution" },
          { id: "s76-2", term: "execution algorithms", hint: "Automated trade implementation systems" },
          { id: "s76-3", term: "market microstructure", hint: "Detailed trading process mechanics" },
          { id: "s76-4", term: "latency", hint: "Time delay in electronic systems" },
          { id: "s76-5", term: "high-frequency strategies", hint: "Rapid trading techniques" },
          { id: "s76-6", term: "dark pool liquidity", hint: "Private trading venues without visible orders" }
        ]
      },
      {
        id: "77",
        story: "Sophia explored commodity trading strategies. She analyzed futures curves and roll yield. Understanding seasonal patterns improved her agricultural investments. She learned about backwardation and contango market conditions.",
        financialTerms: [
          { id: "s77-1", term: "commodity trading", hint: "Buying and selling raw materials" },
          { id: "s77-2", term: "futures curves", hint: "Price relationships across delivery dates" },
          { id: "s77-3", term: "roll yield", hint: "Return from maintaining futures positions" },
          { id: "s77-4", term: "seasonal patterns", hint: "Recurring price cycles throughout year" },
          { id: "s77-5", term: "backwardation", hint: "Market condition with higher spot than future prices" },
          { id: "s77-6", term: "contango", hint: "Market condition with higher future than spot prices" }
        ]
      },
      {
        id: "78",
        story: "James studied credit analysis techniques. He analyzed financial statements and debt covenants. Understanding default probabilities improved his bond selection process. He learned about recovery rates and subordination structures.",
        financialTerms: [
          { id: "s78-1", term: "credit analysis", hint: "Evaluating borrower repayment ability" },
          { id: "s78-2", term: "financial statements", hint: "Documents showing company financial condition" },
          { id: "s78-3", term: "debt covenants", hint: "Legal borrowing agreement restrictions" },
          { id: "s78-4", term: "default probabilities", hint: "Likelihood of payment failure" },
          { id: "s78-5", term: "recovery rates", hint: "Percentage recouped after default" },
          { id: "s78-6", term: "subordination", hint: "Priority ranking for debt repayment" }
        ]
      },
      {
        id: "79",
        story: "Lily studied merger arbitrage strategies. She analyzed deal spreads and regulatory approval processes. Understanding deal breakage risk improved her event-driven investing. She learned about tender offers and proxy contests.",
        financialTerms: [
          { id: "s79-1", term: "merger arbitrage", hint: "Profiting from corporate acquisition price differences" },
          { id: "s79-2", term: "deal spreads", hint: "Price gaps between current and offer prices" },
          { id: "s79-3", term: "regulatory approval", hint: "Government permission for business combinations" },
          { id: "s79-4", term: "deal breakage", hint: "Failed acquisition risk" },
          { id: "s79-5", term: "event-driven investing", hint: "Strategies based on corporate actions" },
          { id: "s79-6", term: "tender offers", hint: "Public offers to buy shares directly" }
        ]
      },
      {
        id: "80",
        story: "Daniel explored distressed debt investing. He analyzed bankruptcy procedures and creditor committees. Understanding restructuring processes improved his recovery value estimates. He learned about debtor-in-possession financing and prepackaged bankruptcies.",
        financialTerms: [
          { id: "s80-1", term: "distressed debt", hint: "Bonds of troubled companies trading below par" },
          { id: "s80-2", term: "bankruptcy procedures", hint: "Legal processes for insolvent companies" },
          { id: "s80-3", term: "creditor committees", hint: "Groups representing lender interests" },
          { id: "s80-4", term: "restructuring", hint: "Reorganizing company financial obligations" },
          { id: "s80-5", term: "recovery value", hint: "Amount recouped from troubled investments" },
          { id: "s80-6", term: "debtor-in-possession", hint: "Financing for bankrupt companies" }
        ]
      },
      {
        id: "81",
        story: "Zoe studied venture capital investment strategies. She analyzed startup valuation methods and funding stages. Understanding term sheets improved her negotiation position. She learned about liquidation preferences and anti-dilution provisions.",
        financialTerms: [
          { id: "s81-1", term: "venture capital", hint: "Financing for early-stage companies" },
          { id: "s81-2", term: "investment strategies", hint: "Plans for managing investments to achieve goals" },
          { id: "s81-3", term: "startup valuation", hint: "Process of determining a new company's worth" },
          { id: "s81-4", term: "funding stages", hint: "Different phases of startup financing" },
          { id: "s81-5", term: "term sheets", hint: "Documents outlining investment terms" },
          { id: "s81-6", term: "negotiation position", hint: "Bargaining stance in business deals" },
          { id: "s81-7", term: "liquidation preferences", hint: "Rights to receive money back before others" },
          { id: "s81-8", term: "anti-dilution provisions", hint: "Protections against ownership percentage reduction" },
        
        ]
      },
      {
        id: "82",
        story: "Henry explored private equity investment strategies. He analyzed leveraged buyout structures and management incentives. Understanding operational improvements improved his value creation approach. He learned about multiple expansion and platform acquisitions.",
        financialTerms: [
          { id: "s82-1", term: "private equity", hint: "Investment in non-public companies" },
          { id: "s82-2", term: "leveraged buyout", hint: "Acquisition using significant borrowed funds" },
          { id: "s82-3", term: "management incentives", hint: "Rewards encouraging executive performance" },
          { id: "s82-4", term: "operational improvements", hint: "Business efficiency enhancements" },
          { id: "s82-5", term: "multiple expansion", hint: "Increasing company valuation ratio" },
          { id: "s82-6", term: "platform acquisitions", hint: "Base companies for additional purchases" }
        ]
      },
      {
        id: "83",
        story: "Chloe studied financial technology innovations. She analyzed blockchain applications and digital payment systems. Understanding smart contracts improved her decentralized finance approach. She learned about tokenization and distributed ledger technology.",
        financialTerms: [
          { id: "s83-1", term: "financial technology", hint: "Digital innovations in financial services" },
          { id: "s83-2", term: "blockchain", hint: "Distributed transaction record system" },
          { id: "s83-3", term: "digital payment", hint: "Electronic money transfer systems" },
          { id: "s83-4", term: "smart contracts", hint: "Self-executing coded agreements" },
          { id: "s83-5", term: "decentralized finance", hint: "Financial services without central authorities" },
          { id: "s83-6", term: "tokenization", hint: "Converting assets into digital tokens" }
        ]
      },
      {
        id: "84",
        story: "Matthew studied quantitative risk management. He analyzed value-at-risk models and stress testing scenarios. Understanding tail risk improved his portfolio protection. He learned about correlation breakdowns and liquidity crises.",
        financialTerms: [
          { id: "s84-1", term: "quantitative risk", hint: "Numerical measurement of potential losses" },
          { id: "s84-2", term: "value-at-risk", hint: "Statistical loss estimate method" },
          { id: "s84-3", term: "stress testing", hint: "Evaluating extreme scenario impacts" },
          { id: "s84-4", term: "tail risk", hint: "Unlikely but severe loss possibility" },
          { id: "s84-5", term: "correlation breakdowns", hint: "Failure of normal relationship patterns" },
          { id: "s84-6", term: "liquidity crises", hint: "Situations where assets cannot be easily sold" }
        ]
      },
      {
        id: "85",
        story: "Abigail studied sustainable investing frameworks. She analyzed environmental impact metrics and social responsibility criteria. Understanding governance factors improved her ESG integration. She learned about impact measurement and sustainability reporting.",
        financialTerms: [
          { id: "s85-1", term: "sustainable investing", hint: "Considering environmental and social factors" },
          { id: "s85-2", term: "environmental impact", hint: "Effects on natural surroundings" },
          { id: "s85-3", term: "social responsibility", hint: "Ethical treatment of people and communities" },
          { id: "s85-4", term: "governance factors", hint: "Company leadership and oversight quality" },
          { id: "s85-5", term: "ESG integration", hint: "Incorporating environmental, social, governance factors" },
          { id: "s85-6", term: "sustainability reporting", hint: "Disclosing environmental and social practices" }
        ]
      },
      {
        id: "86",
        story: "Samuel studied behavioral finance applications. He analyzed investor psychology and market sentiment indicators. Understanding cognitive biases improved his contrarian approach. He learned about herding behavior and overconfidence effects.",
        financialTerms: [
          { id: "s86-1", term: "behavioral finance", hint: "Study of psychological effects on financial decisions" },
          { id: "s86-2", term: "investor psychology", hint: "Mental processes affecting investment choices" },
          { id: "s86-3", term: "market sentiment", hint: "Collective investor attitude" },
          { id: "s86-4", term: "cognitive biases", hint: "Systematic thinking errors" },
          { id: "s86-5", term: "contrarian approach", hint: "Strategy opposing prevailing market views" },
          { id: "s86-6", term: "herding behavior", hint: "Following group investment actions" }
        ]
      },
      {
        id: "87",
        story: "Grace studied international tax planning. She analyzed tax treaties and foreign tax credits. Understanding controlled foreign corporations improved her global strategy. She learned about transfer pricing and offshore structures.",
        financialTerms: [
          { id: "s87-1", term: "international tax", hint: "Cross-border taxation rules" },
          { id: "s87-2", term: "tax treaties", hint: "Agreements between countries on taxation" },
          { id: "s87-3", term: "foreign tax credits", hint: "Reduction in home taxes for foreign taxes paid" },
          { id: "s87-4", term: "controlled foreign corporations", hint: "Overseas companies with domestic ownership" },
          { id: "s87-5", term: "transfer pricing", hint: "Valuing transactions between related entities" },
          { id: "s87-6", term: "offshore structures", hint: "Business arrangements in foreign jurisdictions" }
        ]
      },
      {
        id: "88",
        story: "Joseph studied currency trading strategies. He analyzed central bank policies and interest rate differentials. Understanding purchasing power parity improved his forex positioning. He learned about carry trades and currency correlations.",
        financialTerms: [
          { id: "s88-1", term: "currency trading", hint: "Buying and selling different national monies" },
          { id: "s88-2", term: "central bank policies", hint: "Monetary authority decisions" },
          { id: "s88-3", term: "interest rate differentials", hint: "Gaps between countries' borrowing costs" },
          { id: "s88-4", term: "purchasing power parity", hint: "Theory of exchange rate equilibrium" },
          { id: "s88-5", term: "forex positioning", hint: "Currency market investment stance" },
          { id: "s88-6", term: "carry trades", hint: "Borrowing low-rate currency to invest in high-rate one" }
        ]
      },
      {
        id: "89",
        story: "Natalie studied inflation-protected investment strategies. She analyzed Treasury Inflation-Protected Securities and real return calculations. Understanding inflation hedging improved her purchasing power preservation. She learned about inflation breakeven rates and CPI adjustments.",
        financialTerms: [
          { id: "s89-1", term: "inflation-protected", hint: "Safeguarded against rising prices" },
          { id: "s89-2", term: "Treasury Inflation-Protected Securities", hint: "Government bonds adjusted for inflation" },
          { id: "s89-3", term: "real return", hint: "Investment gains after inflation" },
          { id: "s89-4", term: "inflation hedging", hint: "Protecting against price increases" },
          { id: "s89-5", term: "purchasing power preservation", hint: "Maintaining money's buying ability" },
          { id: "s89-6", term: "inflation breakeven", hint: "Difference between nominal and inflation-adjusted yields" }
        ]
      },
      {
        id: "90",
        story: "Ryan studied concentrated position management. He analyzed single-stock risk and diversification strategies. Understanding tax-efficient liquidation improved his wealth transition planning. He learned about exchange funds and equity collars.",
        financialTerms: [
          { id: "s90-1", term: "concentrated position", hint: "Large holding in single investment" },
          { id: "s90-2", term: "single-stock risk", hint: "Danger from overexposure to one company" },
          { id: "s90-3", term: "diversification strategies", hint: "Methods to spread investment risk" },
          { id: "s90-4", term: "tax-efficient liquidation", hint: "Selling assets while minimizing taxes" },
          { id: "s90-5", term: "wealth transition", hint: "Transferring assets between generations" },
          { id: "s90-6", term: "exchange funds", hint: "Pooled investments diversifying concentrated holdings" }
        ]
      },
      {
        id: "91",
        story: "Isabella studied municipal bond analysis. She researched general obligation and revenue bonds. Understanding credit ratings improved her risk assessment. She learned about bond insurance and call provisions in the municipal market.",
        financialTerms: [
          { id: "s91-1", term: "municipal bond", hint: "Debt issued by local governments" },
          { id: "s91-2", term: "general obligation", hint: "Bonds backed by government taxing power" },
          { id: "s91-3", term: "revenue bonds", hint: "Debt repaid from specific income sources" },
          { id: "s91-4", term: "credit ratings", hint: "Assessments of borrower repayment ability" },
          { id: "s91-5", term: "bond insurance", hint: "Guarantee against issuer default" },
          { id: "s91-6", term: "call provisions", hint: "Terms allowing early bond redemption" }
        ]
      },
      {
        id: "92",
        story: "Michael studied retirement healthcare planning. He analyzed Medicare enrollment options and supplemental insurance. Understanding long-term care needs improved his financial projections. He learned about health savings accounts and medical expense deductions.",
        financialTerms: [
          { id: "s92-1", term: "retirement healthcare", hint: "Medical coverage after working years" },
          { id: "s92-2", term: "Medicare enrollment", hint: "Process of joining government health program" },
          { id: "s92-3", term: "supplemental insurance", hint: "Additional coverage beyond primary policy" },
          { id: "s92-4", term: "long-term care", hint: "Extended medical assistance services" },
          { id: "s92-5", term: "health savings accounts", hint: "Tax-advantaged medical expense funds" },
          { id: "s92-6", term: "medical expense deductions", hint: "Tax reductions for healthcare costs" }
        ]
      },
      {
        id: "93",
        story: "Sophia studied executive compensation planning. She analyzed equity-based incentives and deferred compensation arrangements. Understanding golden parachutes improved her contract negotiations. She learned about stock option strategies and restricted stock units.",
        financialTerms: [
          { id: "s93-1", term: "executive compensation", hint: "Payment packages for senior management" },
          { id: "s93-2", term: "equity-based incentives", hint: "Rewards using company ownership" },
          { id: "s93-3", term: "deferred compensation", hint: "Payment postponed to future periods" },
          { id: "s93-4", term: "golden parachutes", hint: "Benefits triggered by company change of control" },
          { id: "s93-5", term: "stock options", hint: "Rights to purchase shares at set prices" },
          { id: "s93-6", term: "restricted stock units", hint: "Company shares granted with limitations" }
        ]
      },
      {
        id: "94",
        story: "Ethan studied commercial real estate investing. He analyzed cap rates and net operating income. Understanding tenant lease structures improved his property valuation. He learned about triple net leases and real estate syndications.",
        financialTerms: [
          { id: "s94-1", term: "commercial real estate", hint: "Property used for business purposes" },
          { id: "s94-2", term: "cap rates", hint: "Property income as percentage of value" },
          { id: "s94-3", term: "net operating income", hint: "Property revenue minus expenses" },
          { id: "s94-4", term: "tenant lease structures", hint: "Rental agreement frameworks" },
          { id: "s94-5", term: "triple net leases", hint: "Agreements where tenant pays all expenses" },
          { id: "s94-6", term: "real estate syndications", hint: "Group property investment structures" }
        ]
      },
      {
        id: "95",
        story: "Olivia studied college funding strategies. She analyzed 529 plans and education savings accounts. Understanding financial aid formulas improved her education planning. She learned about scholarship opportunities and student loan options.",
        financialTerms: [
          { id: "s95-1", term: "college funding", hint: "Financing higher education expenses" },
          { id: "s95-2", term: "529 plans", hint: "Tax-advantaged education savings programs" },
          { id: "s95-3", term: "education savings accounts", hint: "Tax-favored learning expense funds" },
          { id: "s95-4", term: "financial aid formulas", hint: "Calculations determining assistance eligibility" },
          { id: "s95-5", term: "scholarship opportunities", hint: "Merit-based education funding awards" },
          { id: "s95-6", term: "student loan options", hint: "Borrowing choices for education expenses" }
        ]
      },
      {
        id: "96",
        story: "William studied charitable giving strategies. He analyzed donor-advised funds and private foundations. Understanding qualified charitable distributions improved his tax planning. He learned about charitable remainder trusts and philanthropic legacy planning.",
        financialTerms: [
          { id: "s96-1", term: "charitable giving", hint: "Donating to nonprofit organizations" },
          { id: "s96-2", term: "donor-advised funds", hint: "Sponsored giving accounts" },
          { id: "s96-3", term: "private foundations", hint: "Independent charitable organizations" },
          { id: "s96-4", term: "qualified charitable distributions", hint: "Direct retirement account donations" },
          { id: "s96-5", term: "charitable remainder trusts", hint: "Split-interest donation arrangements" },
          { id: "s96-6", term: "philanthropic legacy", hint: "Long-term charitable impact planning" }
        ]
      },
      {
        id: "97",
        story: "Emma studied business succession planning. She analyzed buy-sell agreements and management buyouts. Understanding business valuation methods improved her exit strategy. She learned about family limited partnerships and installment sales.",
        financialTerms: [
          { id: "s97-1", term: "business succession", hint: "Company ownership transfer planning" },
          { id: "s97-2", term: "buy-sell agreements", hint: "Contracts governing ownership changes" },
          { id: "s97-3", term: "management buyouts", hint: "Company purchases by existing executives" },
          { id: "s97-4", term: "business valuation", hint: "Determining company worth" },
          { id: "s97-5", term: "family limited partnerships", hint: "Shared family business structures" },
          { id: "s97-6", term: "installment sales", hint: "Transactions with payments over time" }
        ]
      },
      {
        id: "98",
        story: "Noah studied digital asset investing. He analyzed cryptocurrency protocols and blockchain applications. Understanding decentralized finance improved his alternative investment approach. He learned about non-fungible tokens and smart contract platforms.",
        financialTerms: [
          { id: "s98-1", term: "digital assets", hint: "Electronic value representations" },
          { id: "s98-2", term: "cryptocurrency protocols", hint: "Rules governing digital currency systems" },
          { id: "s98-3", term: "blockchain applications", hint: "Uses for distributed ledger technology" },
          { id: "s98-4", term: "decentralized finance", hint: "Financial services without central authorities" },
          { id: "s98-5", term: "non-fungible tokens", hint: "Unique digital ownership certificates" },
          { id: "s98-6", term: "smart contract platforms", hint: "Systems supporting self-executing agreements" }
        ]
      },
      {
        id: "99",
        story: "Charlotte studied retirement plan fiduciary responsibilities. She analyzed ERISA requirements and investment policy statements. Understanding prudent investor rules improved her plan governance. She learned about prohibited transactions and fiduciary liability insurance.",
        financialTerms: [
          { id: "s99-1", term: "fiduciary responsibilities", hint: "Legal obligations to act in others' best interests" },
          { id: "s99-2", term: "ERISA requirements", hint: "Federal retirement plan regulations" },
          { id: "s99-3", term: "investment policy statements", hint: "Documents guiding investment decisions" },
          { id: "s99-4", term: "prudent investor rules", hint: "Standards for responsible investing" },
          { id: "s99-5", term: "prohibited transactions", hint: "Forbidden retirement plan activities" },
          { id: "s99-6", term: "fiduciary liability", hint: "Legal responsibility for investment decisions" }
        ]
      },
      {
        id: "100",
        story: "Benjamin studied advanced portfolio optimization. He analyzed factor exposures and efficient frontiers. Understanding risk parity improved his asset allocation approach. He learned about Monte Carlo simulations and dynamic portfolio construction.",
        financialTerms: [
          { id: "s100-1", term: "portfolio optimization", hint: "Maximizing returns for given risk levels" },
          { id: "s100-2", term: "factor exposures", hint: "Investment sensitivity to specific characteristics" },
          { id: "s100-3", term: "efficient frontiers", hint: "Optimal risk-return combinations" },
          { id: "s100-4", term: "risk parity", hint: "Equal risk contribution approach" },
          { id: "s100-5", term: "Monte Carlo simulations", hint: "Random probability modeling technique" },
          { id: "s100-6", term: "dynamic portfolio construction", hint: "Adaptive investment assembly methods" }
        ]
      }
];

export const getRandomStories = (): GameData['easy'] => {
  const storiesCopy = [...shortFinancialStories];
  
  // Fisher-Yates shuffle algorithm
  for (let i = storiesCopy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [storiesCopy[i], storiesCopy[j]] = [storiesCopy[j], storiesCopy[i]];
  }
  
  // Take the first 5 stories from the shuffled array
  return storiesCopy.slice(0, 5).map(story => ({
    ...story,
    id: parseInt(story.id)
  }));
};