import { GameData } from '../types/game';

export const additionalEasyStories: GameData['easy'] = [
  {
    id: 1,
    story: "Maya learned about personal finance through budgeting apps. She discovered the importance of tracking expenses and setting financial goals. She started using digital tools for expense tracking and automated savings. Understanding the difference between needs and wants helped her make better spending decisions.",
    financialTerms: [
      { id: "e1-1", term: "budgeting", hint: "Process of planning income and expenses" },
      { id: "e1-2", term: "expenses", hint: "Money spent on goods and services" },
      { id: "e1-3", term: "automated savings", hint: "System that automatically transfers money to savings" },
      { id: "e1-4", term: "financial goals", hint: "Specific targets for money management" },
      { id: "e1-5", term: "tracking", hint: "Recording and monitoring financial transactions" },
      { id: "e1-6", term: "personal finance", hint: "Managing individual money and financial decisions" },
      { id: "e1-7", term: "digital tools", hint: "Software and apps for managing money" },
      { id: "e1-8", term: "spending decisions", hint: "Choices made about how to use money" },
      { id: "e1-9", term: "needs", hint: "Essential expenses required for living" },
      { id: "e1-10", term: "wants", hint: "Non-essential purchases or desires" },
      { id: "e1-11", term: "expense tracking", hint: "Monitoring and recording spending habits" }
    ]
  },
  {
    id: 2,
    story: "Carlos explored the world of online banking. He learned about mobile check deposits and electronic fund transfers. He set up automatic bill payments and discovered the convenience of peer-to-peer payment apps. Understanding digital security measures helped him protect his online transactions.",
    financialTerms: [
      { id: "e2-1", term: "online banking", hint: "Managing bank accounts through the internet" },
      { id: "e2-2", term: "mobile check deposits", hint: "Depositing checks by taking photos with a mobile device" },
      { id: "e2-3", term: "electronic fund transfers", hint: "Moving money between accounts digitally" },
      { id: "e2-4", term: "automatic bill payments", hint: "Scheduled automatic payments for recurring bills" },
      { id: "e2-5", term: "peer-to-peer payment apps", hint: "Direct money transfers between individuals using mobile apps" },
      { id: "e2-6", term: "digital security measures", hint: "Protection of online financial activities and data" },
      { id: "e2-7", term: "online transactions", hint: "Financial exchanges conducted over the internet" }
    ]
  },
  {
    id: 3,
    story: "Priya started investing in index funds. She understood the concept of passive investing and market diversification. She learned about dollar-cost averaging and the power of long-term investing. Regular portfolio rebalancing became part of her investment strategy.",
    financialTerms: [
      { id: "e3-1", term: "index funds", hint: "Investment funds tracking market indexes" },
      { id: "e3-2", term: "passive investing", hint: "Investment strategy with minimal trading" },
      { id: "e3-3", term: "market diversification", hint: "Spreading investments across different market sectors" },
      { id: "e3-4", term: "dollar-cost averaging", hint: "Strategy of investing fixed amounts at regular intervals" },
      { id: "e3-5", term: "long-term investing", hint: "Investment strategy focused on holding assets for extended periods" },
      { id: "e3-6", term: "portfolio rebalancing", hint: "Adjusting investment proportions to original targets" },
      { id: "e3-7", term: "investment strategy", hint: "Plan for allocating investment resources to achieve goals" }
    ]
  },
  {
    id: 4,
    story: "Kevin explored insurance options for his family. He compared different health insurance plans and understood deductibles. He also learned about life insurance policies and disability coverage. Understanding insurance premiums and coverage limits helped him make informed decisions.",
    financialTerms: [
      { id: "e4-1", term: "insurance", hint: "Protection against financial loss" },
      { id: "e4-2", term: "deductibles", hint: "Amount paid before insurance coverage begins" },
      { id: "e4-3", term: "premiums", hint: "Regular payments for insurance coverage" },
      { id: "e4-4", term: "coverage", hint: "Protection provided by insurance policy" },
      { id: "e4-5", term: "policies", hint: "Formal insurance contracts" }
    ]
  },
  {
    id: 5,
    story: "Aisha learned about credit management. She monitored her credit score and understood credit utilization. She learned how to dispute errors on her credit report and maintain good credit habits. Understanding the factors affecting credit scores helped her improve her financial standing.",
    financialTerms: [
      { id: "e5-1", term: "credit score", hint: "Numerical rating of creditworthiness" },
      { id: "e5-2", term: "utilization", hint: "Percentage of available credit being used" },
      { id: "e5-3", term: "credit report", hint: "Record of credit history and behavior" },
      { id: "e5-4", term: "dispute", hint: "Challenge incorrect information" },
      { id: "e5-5", term: "financial standing", hint: "Overall financial health and position" }
    ]
  }
];