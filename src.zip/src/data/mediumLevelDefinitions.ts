import { GameData } from '../types/game';

interface SimplifiedDefinition {
  id: number;
  question: string;
  financialTerms: { id: string; term: string; hint: string; }[];
}

export const financialDefinitions: SimplifiedDefinition[] = [
  { id: 1, question: "What helps you organize and track your resources?", financialTerms: [{ id: "m1-1", term: "budget", hint: "A plan to manage what you have" }] },
  { id: 2, question: "What increases when you set aside resources?", financialTerms: [{ id: "m2-1", term: "savings", hint: "Reserved resources for future use" }] },
  { id: 3, question: "What do you receive for your work?", financialTerms: [{ id: "m3-1", term: "income", hint: "Regular earnings from effort" }] },
  { id: 4, question: "What reduces your available resources?", financialTerms: [{ id: "m4-1", term: "expenses", hint: "Necessary costs and payments" }] },
  { id: 5, question: "What builds up when you borrow?", financialTerms: [{ id: "m5-1", term: "debt", hint: "Amount owed to others" }] },
  { id: 6, question: "What card directly uses your own resources?", financialTerms: [{ id: "m6-1", term: "debit card", hint: "Instant access to your funds" }] },
  { id: 7, question: "What card lets you buy now and pay later?", financialTerms: [{ id: "m7-1", term: "credit card", hint: "Borrowed purchasing power" }] },
  { id: 8, question: "What shows all your account activities?", financialTerms: [{ id: "m8-1", term: "statement", hint: "Record of all transactions" }] },
  { id: 9, question: "What's left to pay?", financialTerms: [{ id: "m9-1", term: "balance", hint: "Remaining amount" }] },
  { id: 10, question: "What protects your stored resources?", financialTerms: [{ id: "m10-1", term: "FDIC insurance", hint: "Safety guarantee for savings" }] },
  { id: 11, question: "What process gradually reduces the value of an asset over time?", financialTerms: [{ id: "m11-1", term: "amortization", hint: "Depreciation over time" }] },
  { id: 12, question: "What ratio measures a company's ability to pay short-term debts?", financialTerms: [{ id: "m12-1", term: "liquidity ratio", hint: "Ability to pay debts" }] },
  { id: 13, question: "What measures a company's total value in the stock market?", financialTerms: [{ id: "m13-1", term: "market capitalization", hint: "Total market value" }] },
  { id: 14, question: "What percentage of profit does a company share with stockholders?", financialTerms: [{ id: "m14-1", term: "dividend yield", hint: "Profit sharing rate" }] },
  { id: 15, question: "What measures an investment's volatility compared to the market?", financialTerms: [{ id: "m15-1", term: "beta coefficient", hint: "Market sensitivity" }] },
  { id: 16, question: "What ratio compares a stock's price to its earnings?", financialTerms: [{ id: "m16-1", term: "price-to-earnings ratio", hint: "Value metric" }] },
  { id: 17, question: "What ratio shows how much a company uses borrowed money?", financialTerms: [{ id: "m17-1", term: "debt-to-equity ratio", hint: "Borrowing level" }] },
  { id: 18, question: "What percentage of revenue becomes profit after expenses?", financialTerms: [{ id: "m18-1", term: "operating margin", hint: "Profit efficiency" }] },
  { id: 19, question: "What money is available for day-to-day business operations?", financialTerms: [{ id: "m19-1", term: "working capital", hint: "Operating funds" }] },
  { id: 20, question: "What document shows money moving in and out of a business?", financialTerms: [{ id: "m20-1", term: "cash flow statement", hint: "Money movement record" }] },
  { id: 21, question: "What fund should you have for unexpected expenses?", financialTerms: [{ id: "m21-1", term: "emergency fund", hint: "Safety net" }] },
  { id: 22, question: "What type of account holds your everyday spending money?", financialTerms: [{ id: "m22-1", term: "checking account", hint: "Daily transactions" }] },
  { id: 23, question: "What do you earn on your savings?", financialTerms: [{ id: "m23-1", term: "interest", hint: "Money earned" }] },
  { id: 24, question: "What represents ownership in a company?", financialTerms: [{ id: "m24-1", term: "stock", hint: "Company shares" }] },
  { id: 25, question: "What strategy spreads risk across different investments?", financialTerms: [{ id: "m25-1", term: "diversification", hint: "Risk spreading" }] },
  { id: 26, question: "What describes a declining market?", financialTerms: [{ id: "m26-1", term: "bear market", hint: "Market decline" }] },
  { id: 27, question: "What describes a rising market?", financialTerms: [{ id: "m27-1", term: "bull market", hint: "Market growth" }] },
  { id: 28, question: "What is a share of company profits paid to stockholders?", financialTerms: [{ id: "m28-1", term: "dividend", hint: "Profit share" }] },
  { id: 29, question: "What option gives the right to buy at a set price?", financialTerms: [{ id: "m29-1", term: "call option", hint: "Purchase right" }] },
  { id: 30, question: "What option gives the right to sell at a set price?", financialTerms: [{ id: "m30-1", term: "put option", hint: "Sell right" }] },
  { id: 31, question: "What financial instrument derives value from another asset?", financialTerms: [{ id: "m31-1", term: "derivative", hint: "Linked contract" }] },
  { id: 32, question: "What strategy protects against potential losses?", financialTerms: [{ id: "m32-1", term: "hedge", hint: "Risk protection" }] },
  { id: 33, question: "What describes how easily an asset can be converted to cash?", financialTerms: [{ id: "m33-1", term: "liquidity", hint: "Cash conversion" }] },
  { id: 34, question: "What causes money to lose purchasing power over time?", financialTerms: [{ id: "m34-1", term: "inflation", hint: "Price increase" }] },
  { id: 35, question: "What causes prices to fall over time?", financialTerms: [{ id: "m35-1", term: "deflation", hint: "Price decrease" }] },
  { id: 36, question: "What period shows declining economic activity?", financialTerms: [{ id: "m36-1", term: "recession", hint: "Economic decline" }] },
  { id: 37, question: "What measures a country's total economic output?", financialTerms: [{ id: "m37-1", term: "gross domestic product", hint: "Economic output" }] },
  { id: 38, question: "What policy involves government spending and taxation?", financialTerms: [{ id: "m38-1", term: "fiscal policy", hint: "Government finance" }] },
  { id: 39, question: "What policy controls money supply and interest rates?", financialTerms: [{ id: "m39-1", term: "monetary policy", hint: "Money control" }] },
  { id: 40, question: "What central bank manages U.S. monetary policy?", financialTerms: [{ id: "m40-1", term: "federal reserve", hint: "Central bank" }] },
  { id: 41, question: "What percentage is charged for borrowing money?", financialTerms: [{ id: "m41-1", term: "interest rate", hint: "Borrowing cost" }] },
  { id: 42, question: "What investment represents a loan to a company or government?", financialTerms: [{ id: "m42-1", term: "bond", hint: "Debt investment" }] },
  { id: 43, question: "What government agency issues U.S. debt securities?", financialTerms: [{ id: "m43-1", term: "treasury", hint: "Government finance" }] },
  { id: 44, question: "What investment pools money from many investors?", financialTerms: [{ id: "m44-1", term: "mutual fund", hint: "Pooled investment" }] },
  { id: 45, question: "What fund trades like a stock but holds multiple assets?", financialTerms: [{ id: "m45-1", term: "exchange-traded fund", hint: "Tradable basket" }] },
  { id: 46, question: "What strategy divides investments among different assets?", financialTerms: [{ id: "m46-1", term: "asset allocation", hint: "Investment mix" }] },
  { id: 47, question: "What describes managing multiple investments together?", financialTerms: [{ id: "m47-1", term: "portfolio management", hint: "Investment oversight" }] },
  { id: 48, question: "What measures how much investment risk you can handle?", financialTerms: [{ id: "m48-1", term: "risk tolerance", hint: "Risk comfort" }] },
  { id: 49, question: "What represents your total financial resources?", financialTerms: [{ id: "m49-1", term: "capital", hint: "Financial resources" }] },
  { id: 50, question: "What represents ownership stake in something?", financialTerms: [{ id: "m50-1", term: "equity", hint: "Ownership share" }] },
  { id: 51, question: "What represents a financial obligation or debt?", financialTerms: [{ id: "m51-1", term: "liability", hint: "Financial obligation" }] },
  { id: 52, question: "What is something of value that you own?", financialTerms: [{ id: "m52-1", term: "asset", hint: "Valuable possession" }] },
  { id: 53, question: "What financial statement shows assets and liabilities?", financialTerms: [{ id: "m53-1", term: "balance sheet", hint: "Financial position" }] },
  { id: 54, question: "What statement shows revenue and expenses?", financialTerms: [{ id: "m54-1", term: "income statement", hint: "Profit report" }] },
  { id: 55, question: "What process reduces an asset's value over time?", financialTerms: [{ id: "m55-1", term: "depreciation", hint: "Value reduction" }] },
  { id: 56, question: "What describes an increase in asset value?", financialTerms: [{ id: "m56-1", term: "appreciation", hint: "Value increase" }] },
  { id: 57, question: "What asset backs a loan?", financialTerms: [{ id: "m57-1", term: "collateral", hint: "Loan security" }] },
  { id: 58, question: "What number measures creditworthiness?", financialTerms: [{ id: "m58-1", term: "credit score", hint: "Credit rating" }] },
  { id: 59, question: "What happens when you fail to repay a loan?", financialTerms: [{ id: "m59-1", term: "default", hint: "Payment failure" }] },
  { id: 60, question: "What legal process handles inability to pay debts?", financialTerms: [{ id: "m60-1", term: "bankruptcy", hint: "Debt relief" }] },
  { id: 61, question: "What happens when a lender takes back property?", financialTerms: [{ id: "m61-1", term: "foreclosure", hint: "Property seizure" }] },
  { id: 62, question: "What process evaluates loan applications?", financialTerms: [{ id: "m62-1", term: "underwriting", hint: "Risk assessment" }] },
  { id: 63, question: "What regular payment is made for insurance?", financialTerms: [{ id: "m63-1", term: "premium", hint: "Insurance cost" }] },
  { id: 64, question: "What amount do you pay before insurance pays?", financialTerms: [{ id: "m64-1", term: "deductible", hint: "Initial payment" }] },
  { id: 65, question: "What investment provides regular payments for life?", financialTerms: [{ id: "m65-1", term: "annuity", hint: "Lifetime income" }] },
  { id: 66, question: "What retirement plan pays regular benefits?", financialTerms: [{ id: "m66-1", term: "pension", hint: "Retirement income" }] },
  { id: 67, question: "What government program provides retirement benefits?", financialTerms: [{ id: "m67-1", term: "social security", hint: "Government benefits" }] },
  { id: 68, question: "What describes postponing taxes until withdrawal?", financialTerms: [{ id: "m68-1", term: "tax-deferred", hint: "Tax delay" }] },
  { id: 69, question: "What spending is for long-term business assets?", financialTerms: [{ id: "m69-1", term: "capital expenditure", hint: "Asset investment" }] },
  { id: 70, question: "What costs run the day-to-day business?", financialTerms: [{ id: "m70-1", term: "operating expense", hint: "Daily costs" }] },
  { id: 71, question: "What money comes in from sales and services?", financialTerms: [{ id: "m71-1", term: "revenue", hint: "Income earned" }] },
  { id: 72, question: "What percentage of sales becomes profit?", financialTerms: [{ id: "m72-1", term: "profit margin", hint: "Profit percentage" }] },
  { id: 73, question: "What measures investment profitability?", financialTerms: [{ id: "m73-1", term: "return on investment", hint: "Profit measure" }] },
  { id: 74, question: "What interest earns interest on itself?", financialTerms: [{ id: "m74-1", term: "compound interest", hint: "Growing interest" }] },
  { id: 75, question: "What interest is calculated on original amount only?", financialTerms: [{ id: "m75-1", term: "simple interest", hint: "Basic interest" }] },
  { id: 76, question: "What is the original amount borrowed or invested?", financialTerms: [{ id: "m76-1", term: "principal", hint: "Initial amount" }] },
  { id: 77, question: "When does an investment or loan come due?", financialTerms: [{ id: "m77-1", term: "maturity", hint: "End date" }] },
  { id: 78, question: "What graph shows interest rates over time?", financialTerms: [{ id: "m78-1", term: "yield curve", hint: "Rate chart" }] },
  { id: 79, question: "What trading profits from price differences?", financialTerms: [{ id: "m79-1", term: "arbitrage", hint: "Price advantage" }] },
  { id: 80, question: "What measures price movement intensity?", financialTerms: [{ id: "m80-1", term: "volatility", hint: "Price swings" }] },
  { id: 81, question: "What account lets you borrow to invest?", financialTerms: [{ id: "m81-1", term: "margin account", hint: "Investment loan" }] },
  { id: 82, question: "What increases potential gains and losses?", financialTerms: [{ id: "m82-1", term: "leverage", hint: "Borrowed power" }] },
  { id: 83, question: "What trading profits from falling prices?", financialTerms: [{ id: "m83-1", term: "short selling", hint: "Decline profit" }] },
  { id: 84, question: "What's a company's first stock sale to public?", financialTerms: [{ id: "m84-1", term: "initial public offering", hint: "First sale" }] },
  { id: 85, question: "What combines two companies into one?", financialTerms: [{ id: "m85-1", term: "merger", hint: "Company union" }] },
  { id: 86, question: "What's buying control of another company?", financialTerms: [{ id: "m86-1", term: "acquisition", hint: "Company purchase" }] },
  { id: 87, question: "What's unwanted company takeover?", financialTerms: [{ id: "m87-1", term: "hostile takeover", hint: "Forced purchase" }] },
  { id: 88, question: "What reinvests dividend payments?", financialTerms: [{ id: "m88-1", term: "dividend reinvestment", hint: "Auto-invest" }] },
  { id: 89, question: "What investment strategy uses regular fixed amounts?", financialTerms: [{ id: "m89-1", term: "dollar cost averaging", hint: "Regular investing" }] },
  { id: 90, question: "What adjusts investment mix back to targets?", financialTerms: [{ id: "m90-1", term: "rebalancing", hint: "Mix adjustment" }] },
  { id: 91, question: "What uses losses to reduce taxes?", financialTerms: [{ id: "m91-1", term: "tax-loss harvesting", hint: "Loss benefit" }] },
  { id: 92, question: "What plans handle wealth after death?", financialTerms: [{ id: "m92-1", term: "estate planning", hint: "Legacy planning" }] },
  { id: 93, question: "What legal arrangement manages assets?", financialTerms: [{ id: "m93-1", term: "trust", hint: "Asset management" }] },
  { id: 94, question: "What legal document distributes assets after death?", financialTerms: [{ id: "m94-1", term: "will", hint: "Legacy document" }] },
  { id: 95, question: "What measures market price trends?", financialTerms: [{ id: "m95-1", term: "moving average", hint: "Trend line" }] },
  { id: 96, question: "What indicates buying or selling pressure?", financialTerms: [{ id: "m96-1", term: "relative strength index", hint: "Momentum gauge" }] },
  { id: 97, question: "What price level stops price drops?", financialTerms: [{ id: "m97-1", term: "support level", hint: "Price floor" }] },
  { id: 98, question: "What price level stops price rises?", financialTerms: [{ id: "m98-1", term: "resistance level", hint: "Price ceiling" }] },
  { id: 99, question: "What average price considers trading volume?", financialTerms: [{ id: "m99-1", term: "volume weighted average price", hint: "Volume price" }] },
  { id: 100, question: "What measures data spread from average?", financialTerms: [{ id: "m100-1", term: "standard deviation", hint: "Variation measure" }] }
]


// Function to get random definitions
export const getRandomDefinitions = (previouslyShown: number[] = []): GameData['medium'] => {
  const definitionsCopy = [...financialDefinitions];
  
  if (previouslyShown.length >= definitionsCopy.length) {
    previouslyShown.length = 0;
  }

  const availableDefinitions = definitionsCopy.filter(def => !previouslyShown.includes(def.id));
  const definitionsToUse = availableDefinitions.length >= 5 ? availableDefinitions : definitionsCopy;
  
  for (let i = definitionsToUse.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [definitionsToUse[i], definitionsToUse[j]] = [definitionsToUse[j], definitionsToUse[i]];
  }

  const numDefinitions = Math.min(5, definitionsToUse.length);
  return definitionsToUse.slice(0, numDefinitions);
};