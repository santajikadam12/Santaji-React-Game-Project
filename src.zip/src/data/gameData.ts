
import { GameData } from '../types/game';
import { shortFinancialStories, getRandomStories } from './shortStories';
import { getRandomDefinitions } from './mediumLevelDefinitions';
import { getUserHardTerms } from './userHardTerms';

// Export the stories for each difficulty level
export const easyLevelData: GameData['easy'] = getRandomStories([]).slice(0, 5);

// Medium level - financial definitions questions (limit to 5 levels)
export const mediumLevelData: GameData['medium'] = getRandomDefinitions([]).slice(0, 5).map(def => ({
  id: def.id,
  question: def.question,
  story: "", // Remove story content
  financialTerms: def.financialTerms
}));

// Hard level - advanced financial terms with hangman style (5 levels)
export const hardLevelData: GameData['hard'] = getUserHardTerms(5).map((term, index) => ({
  id: index + 1,
  question: term.question,
  story: "",
  financialTerms: [{
    ...term,
    id: `h${index + 1}`,
    hint: term.hint,
    term: "_".repeat(term.term.length) // Display term as underscores for hangman
  }]
}));

// Export combined game data
const gameData: GameData = {
  easy: easyLevelData,
  medium: mediumLevelData,
  hard: hardLevelData
};

export default gameData;
