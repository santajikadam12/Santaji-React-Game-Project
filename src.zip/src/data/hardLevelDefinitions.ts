import { GameData } from '../types/game';
import { hardTerms } from './hardTerms';

interface HardDefinition {
  id: number;
  question: string;
  financialTerms: { id: string; term: string; hint: string; }[];
}

// Get random terms for hangman game
const getRandomTerms = (count: number = 5): HardDefinition[] => {
  const termsCopy = [...hardTerms];
  const result: HardDefinition[] = [];
  
  // Shuffle array
  for (let i = termsCopy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [termsCopy[i], termsCopy[j]] = [termsCopy[j], termsCopy[i]];
  }

  // Take first 'count' terms
  for (let i = 0; i < count && i < termsCopy.length; i++) {
    result.push({
      id: i + 1,
      question: termsCopy[i].question || 'Guess the financial term:',
      financialTerms: [{
        id: `h${i+1}`,
        term: termsCopy[i].term,
        hint: termsCopy[i].hint
      }]
    });
  }

  return result;
};

export const hardLevelDefinitions: HardDefinition[] = getRandomTerms(5);

// Previous definitions kept for reference
const allHardDefinitions: HardDefinition[] = [
  { id: 1, question: "What financial metric evaluates a company's ability to generate cash relative to its market value?", financialTerms: [{ id: "h1-1", term: "free cash flow yield", hint: "Cash generation efficiency" }] },
  { id: 2, question: "What describes the risk that changes in interest rates will affect investment values?", financialTerms: [{ id: "h2-1", term: "duration risk", hint: "Rate sensitivity measure" }] },
  { id: 3, question: "What investment strategy aims to profit from temporary price inefficiencies between related securities?", financialTerms: [{ id: "h3-1", term: "statistical arbitrage", hint: "Price pattern trading" }] },
  { id: 4, question: "What type of analysis examines past trading patterns to forecast future price movements?", financialTerms: [{ id: "h4-1", term: "technical analysis", hint: "Chart pattern study" }] },
  { id: 5, question: "What describes the practice of spreading investments across different countries and regions?", financialTerms: [{ id: "h5-1", term: "global diversification", hint: "Worldwide allocation" }] },
  { id: 6, question: "What risk occurs when a counterparty fails to fulfill their financial obligations?", financialTerms: [{ id: "h6-1", term: "counterparty risk", hint: "Default exposure" }] },
  { id: 7, question: "What investment vehicle pools capital to invest in private companies?", financialTerms: [{ id: "h7-1", term: "venture capital fund", hint: "Startup investor" }] },
  { id: 8, question: "What describes the difference between an asset's purchase price and its current market value?", financialTerms: [{ id: "h8-1", term: "unrealized gain", hint: "Paper profit" }] },
  { id: 9, question: "What financial instrument derives its value from the performance of an underlying index?", financialTerms: [{ id: "h9-1", term: "index derivative", hint: "Market tracker" }] },
  { id: 10, question: "What strategy involves simultaneously buying and selling related securities to profit from price discrepancies?", financialTerms: [{ id: "h10-1", term: "pairs trading", hint: "Correlation betting" }] },
  { id: 11, question: "What describes the risk that a security cannot be sold quickly without significant price impact?", financialTerms: [{ id: "h11-1", term: "liquidity risk", hint: "Trading difficulty" }] },
  { id: 12, question: "What investment approach focuses on companies trading below their intrinsic value?", financialTerms: [{ id: "h12-1", term: "value investing", hint: "Bargain hunting" }] },
  { id: 13, question: "What describes the total return of an investment including price changes and income?", financialTerms: [{ id: "h13-1", term: "total return", hint: "Complete performance" }] },
  { id: 14, question: "What risk management technique involves setting predetermined exit points?", financialTerms: [{ id: "h14-1", term: "stop loss order", hint: "Loss limiter" }] },
  { id: 15, question: "What describes the practice of investing in companies with strong environmental and social practices?", financialTerms: [{ id: "h15-1", term: "sustainable investing", hint: "Ethical allocation" }] },
  { id: 16, question: "What metric measures a portfolio's risk-adjusted return relative to a benchmark?", financialTerms: [{ id: "h16-1", term: "information ratio", hint: "Skill measure" }] },
  { id: 17, question: "What describes the minimum return an investor requires for a given level of risk?", financialTerms: [{ id: "h17-1", term: "required return", hint: "Risk compensation" }] },
  { id: 18, question: "What strategy involves buying assets in one market and selling in another to profit from price differences?", financialTerms: [{ id: "h18-1", term: "market arbitrage", hint: "Price gap trading" }] },
  { id: 19, question: "What describes the risk that inflation will erode the value of investment returns?", financialTerms: [{ id: "h19-1", term: "inflation risk", hint: "Purchasing power" }] },
  { id: 20, question: "What investment approach focuses on companies with strong competitive advantages?", financialTerms: [{ id: "h20-1", term: "moat investing", hint: "Advantage focus" }] },
  { id: 21, question: "What measures a portfolio's risk relative to potential returns?", financialTerms: [{ id: "h21-1", term: "sharpe ratio", hint: "Risk-return metric" }] },
  { id: 22, question: "What describes the systematic risk that affects all investments?", financialTerms: [{ id: "h22-1", term: "market risk", hint: "Unavoidable risk" }] },
  { id: 23, question: "What investment vehicle pools money to invest in real estate?", financialTerms: [{ id: "h23-1", term: "real estate investment trust", hint: "Property fund" }] },
  { id: 24, question: "What describes the risk of currency value changes?", financialTerms: [{ id: "h24-1", term: "foreign exchange risk", hint: "Currency exposure" }] },
  { id: 25, question: "What investment strategy focuses on environmental and social impact?", financialTerms: [{ id: "h25-1", term: "impact investing", hint: "Social benefit" }] },
  { id: 26, question: "What describes the difference between spot and futures prices?", financialTerms: [{ id: "h26-1", term: "basis risk", hint: "Price spread" }] },
  { id: 27, question: "What investment approach focuses on companies with high growth potential?", financialTerms: [{ id: "h27-1", term: "growth investing", hint: "Expansion focus" }] },
  { id: 28, question: "What describes the risk of changes in political policies?", financialTerms: [{ id: "h28-1", term: "political risk", hint: "Policy exposure" }] },
  { id: 29, question: "What investment strategy profits from corporate actions?", financialTerms: [{ id: "h29-1", term: "event driven investing", hint: "Action trading" }] },
  { id: 30, question: "What describes the risk of technology becoming obsolete?", financialTerms: [{ id: "h30-1", term: "obsolescence risk", hint: "Tech aging" }] },
  { id: 31, question: "What investment approach focuses on undervalued assets?", financialTerms: [{ id: "h31-1", term: "distressed investing", hint: "Troubled assets" }] },
  { id: 32, question: "What describes the risk of changes in tax laws?", financialTerms: [{ id: "h32-1", term: "tax risk", hint: "Law exposure" }] },
  { id: 33, question: "What investment strategy focuses on commodity price changes?", financialTerms: [{ id: "h33-1", term: "commodity trading", hint: "Resource trading" }] },
  { id: 34, question: "What describes the risk of business model failure?", financialTerms: [{ id: "h34-1", term: "business risk", hint: "Model failure" }] },
  { id: 35, question: "What investment approach focuses on market neutral positions?", financialTerms: [{ id: "h35-1", term: "absolute return", hint: "Neutral strategy" }] },
  { id: 36, question: "What describes the risk of legal system changes?", financialTerms: [{ id: "h36-1", term: "regulatory risk", hint: "Rule changes" }] },
  { id: 37, question: "What investment strategy focuses on convertible securities?", financialTerms: [{ id: "h37-1", term: "convertible arbitrage", hint: "Convert profit" }] },
  { id: 38, question: "What describes the risk of reputation damage?", financialTerms: [{ id: "h38-1", term: "reputational risk", hint: "Image damage" }] },
  { id: 39, question: "What investment approach focuses on merger situations?", financialTerms: [{ id: "h39-1", term: "merger arbitrage", hint: "Deal profit" }] },
  { id: 40, question: "What describes the risk of economic system failure?", financialTerms: [{ id: "h40-1", term: "systemic risk", hint: "System failure" }] },
  { id: 41, question: "What investment strategy focuses on volatility trading?", financialTerms: [{ id: "h41-1", term: "volatility arbitrage", hint: "Price swing" }] },
  { id: 42, question: "What describes the risk of operational failures?", financialTerms: [{ id: "h42-1", term: "operational risk", hint: "Process failure" }] },
  { id: 43, question: "What investment approach focuses on fixed income securities?", financialTerms: [{ id: "h43-1", term: "fixed income arbitrage", hint: "Bond profit" }] },
  { id: 44, question: "What describes the risk of model assumptions failing?", financialTerms: [{ id: "h44-1", term: "model risk", hint: "Theory failure" }] },
  { id: 45, question: "What investment strategy focuses on sector rotation?", financialTerms: [{ id: "h45-1", term: "sector rotation", hint: "Industry shift" }] },
  { id: 46, question: "What describes the risk of settlement system failure?", financialTerms: [{ id: "h46-1", term: "settlement risk", hint: "Trade failure" }] },
  { id: 47, question: "What investment approach focuses on dividend capture?", financialTerms: [{ id: "h47-1", term: "dividend arbitrage", hint: "Payment profit" }] },
  { id: 48, question: "What describes the risk of fraud or misconduct?", financialTerms: [{ id: "h48-1", term: "fraud risk", hint: "Deception risk" }] },
  { id: 49, question: "What investment strategy focuses on option combinations?", financialTerms: [{ id: "h49-1", term: "options arbitrage", hint: "Contract profit" }] },
  { id: 50, question: "What describes the risk of technology system failure?", financialTerms: [{ id: "h50-1", term: "technology risk", hint: "System crash" }] },
  { id: 51, question: "What investment approach focuses on global macro trends?", financialTerms: [{ id: "h51-1", term: "macro trading", hint: "Global trends" }] },
  { id: 52, question: "What describes the risk of key person departure?", financialTerms: [{ id: "h52-1", term: "key person risk", hint: "Talent loss" }] },
  { id: 53, question: "What investment strategy focuses on capital structure?", financialTerms: [{ id: "h53-1", term: "capital structure arbitrage", hint: "Structure profit" }] },
  { id: 54, question: "What describes the risk of supply chain disruption?", financialTerms: [{ id: "h54-1", term: "supply chain risk", hint: "Chain break" }] },
  { id: 55, question: "What investment approach focuses on weather derivatives?", financialTerms: [{ id: "h55-1", term: "weather trading", hint: "Climate profit" }] },
  { id: 56, question: "What describes the risk of intellectual property loss?", financialTerms: [{ id: "h56-1", term: "intellectual property risk", hint: "Patent loss" }] },
  { id: 57, question: "What investment strategy focuses on index changes?", financialTerms: [{ id: "h57-1", term: "index arbitrage", hint: "Market gap" }] },
  { id: 58, question: "What describes the risk of environmental damage?", financialTerms: [{ id: "h58-1", term: "environmental risk", hint: "Nature harm" }] },
  { id: 59, question: "What investment approach focuses on statistical patterns?", financialTerms: [{ id: "h59-1", term: "quantitative trading", hint: "Math profit" }] },
  { id: 60, question: "What describes the risk of social media backlash?", financialTerms: [{ id: "h60-1", term: "social media risk", hint: "Online harm" }] },
  { id: 61, question: "What investment strategy focuses on credit spreads?", financialTerms: [{ id: "h61-1", term: "credit arbitrage", hint: "Spread profit" }] },
  { id: 62, question: "What describes the risk of data breach?", financialTerms: [{ id: "h62-1", term: "cybersecurity risk", hint: "Data theft" }] },
  { id: 63, question: "What investment approach focuses on relative value?", financialTerms: [{ id: "h63-1", term: "relative value arbitrage", hint: "Value gap" }] },
  { id: 64, question: "What describes the risk of natural disasters?", financialTerms: [{ id: "h64-1", term: "catastrophe risk", hint: "Nature event" }] },
  { id: 65, question: "What investment strategy focuses on currency pairs?", financialTerms: [{ id: "h65-1", term: "currency arbitrage", hint: "Money gap" }] },
  { id: 66, question: "What describes the risk of pandemic impact?", financialTerms: [{ id: "h66-1", term: "pandemic risk", hint: "Health crisis" }] },
  { id: 67, question: "What investment approach focuses on factor investing?", financialTerms: [{ id: "h67-1", term: "factor investing", hint: "Style focus" }] },
  { id: 68, question: "What describes the risk of demographic changes?", financialTerms: [{ id: "h68-1", term: "demographic risk", hint: "Population shift" }] },
  { id: 69, question: "What investment strategy focuses on momentum?", financialTerms: [{ id: "h69-1", term: "momentum trading", hint: "Trend follow" }] },
  { id: 70, question: "What describes the risk of climate change?", financialTerms: [{ id: "h70-1", term: "climate risk", hint: "Weather impact" }] },
  { id: 71, question: "What investment approach focuses on quality factors?", financialTerms: [{ id: "h71-1", term: "quality investing", hint: "Strong firms" }] },
  { id: 72, question: "What describes the risk of geopolitical events?", financialTerms: [{ id: "h72-1", term: "geopolitical risk", hint: "Global events" }] },
  { id: 73, question: "What investment strategy focuses on size premium?", financialTerms: [{ id: "h73-1", term: "size investing", hint: "Scale focus" }] },
  { id: 74, question: "What describes the risk of resource depletion?", financialTerms: [{ id: "h74-1", term: "resource risk", hint: "Supply end" }] },
  { id: 75, question: "What investment approach focuses on low volatility?", financialTerms: [{ id: "h75-1", term: "low volatility investing", hint: "Stable focus" }] },
  { id: 76, question: "What describes the risk of technological disruption?", financialTerms: [{ id: "h76-1", term: "disruption risk", hint: "Tech change" }] },
  { id: 77, question: "What investment strategy focuses on value premium?", financialTerms: [{ id: "h77-1", term: "value premium", hint: "Worth extra" }] },
  { id: 78, question: "What describes the risk of social unrest?", financialTerms: [{ id: "h78-1", term: "social risk", hint: "Public chaos" }] },
  { id: 79, question: "What investment approach focuses on carry trades?", financialTerms: [{ id: "h79-1", term: "carry trading", hint: "Rate profit" }] },
  { id: 80, question: "What describes the risk of infrastructure failure?", financialTerms: [{ id: "h80-1", term: "infrastructure risk", hint: "System fail" }] },
  { id: 81, question: "What investment strategy focuses on smart beta?", financialTerms: [{ id: "h81-1", term: "smart beta", hint: "Factor mix" }] },
  { id: 82, question: "What describes the risk of sovereign default?", financialTerms: [{ id: "h82-1", term: "sovereign risk", hint: "Nation fail" }] },
  { id: 83, question: "What investment approach focuses on thematic investing?", financialTerms: [{ id: "h83-1", term: "thematic investing", hint: "Trend focus" }] },
  { id: 84, question: "What describes the risk of market manipulation?", financialTerms: [{ id: "h84-1", term: "manipulation risk", hint: "Price trick" }] },
  { id: 85, question: "What investment strategy focuses on behavioral bias?", financialTerms: [{ id: "h85-1", term: "behavioral investing", hint: "Mind profit" }] },
  { id: 86, question: "What describes the risk of trade barriers?", financialTerms: [{ id: "h86-1", term: "trade risk", hint: "Border block" }] },
  { id: 87, question: "What investment approach focuses on alternative data?", financialTerms: [{ id: "h87-1", term: "alternative data investing", hint: "New info" }] },
  { id: 88, question: "What describes the risk of currency controls?", financialTerms: [{ id: "h88-1", term: "currency control risk", hint: "Money block" }] },
  { id: 89, question: "What investment strategy focuses on machine learning?", financialTerms: [{ id: "h89-1", term: "algorithmic trading", hint: "Robot trade" }] },
  { id: 90, question: "What describes the risk of market structure changes?", financialTerms: [{ id: "h90-1", term: "market structure risk", hint: "System shift" }] },
  { id: 91, question: "What investment approach focuses on social sentiment?", financialTerms: [{ id: "h91-1", term: "sentiment trading", hint: "Mood profit" }] },
  { id: 92, question: "What describes the risk of talent shortage?", financialTerms: [{ id: "h92-1", term: "talent risk", hint: "Skill gap" }] },
  { id: 93, question: "What investment strategy focuses on blockchain assets?", financialTerms: [{ id: "h93-1", term: "crypto investing", hint: "Digital coins" }] },
  { id: 94, question: "What describes the risk of innovation failure?", financialTerms: [{ id: "h94-1", term: "innovation risk", hint: "New fail" }] },
  { id: 95, question: "What investment approach focuses on carbon credits?", financialTerms: [{ id: "h95-1", term: "carbon trading", hint: "Green profit" }] },
  { id: 96, question: "What describes the risk of competitive disruption?", financialTerms: [{ id: "h96-1", term: "competitive risk", hint: "Rival threat" }] },
  { id: 97, question: "What investment strategy focuses on water rights?", financialTerms: [{ id: "h97-1", term: "water investing", hint: "Resource right" }] },
  { id: 98, question: "What describes the risk of cultural conflicts?", financialTerms: [{ id: "h98-1", term: "cultural risk", hint: "Value clash" }] },
  { id: 99, question: "What investment strategy focuses on space technology?", financialTerms: [{ id: "h99-1", term: "space investing", hint: "Sky profit" }] },
  { id: 100, question: "What describes the risk of ethical violations?", financialTerms: [{ id: "h100-1", term: "ethical risk", hint: "Moral fail" }] }
];