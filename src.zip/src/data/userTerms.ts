import { FinancialTerm } from '../types/game';
import { mediumTerms } from './mediumTerms';

// Store user-specific term selections
type UserTermsStore = {
  mediumTerms: FinancialTerm[];
  userId: string | null;
};

// Initialize with empty state
const userTermsStore: UserTermsStore = {
  mediumTerms: [],
  userId: null
};

/**
 * Generate a simple user ID for the session
 * This creates a unique identifier for each user session
 */
export const generateUserId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

/**
 * Get the current user ID or generate a new one
 */
export const getUserId = (): string => {
  // Try to get from localStorage first
  let userId = localStorage.getItem('fin_terms_user_id');
  
  // If no user ID exists, create one and store it
  if (!userId) {
    userId = generateUserId();
    localStorage.setItem('fin_terms_user_id', userId);
  }
  
  return userId;
};

/**
 * Select random terms for a specific user
 * This ensures each user gets a consistent set of terms
 * @param count Number of terms to select
 * @returns Array of selected financial terms
 */
export const getUserMediumTerms = (count: number = 25): FinancialTerm[] => {
  const userId = getUserId();
  
  // If we already have terms for this user, return them
  if (userTermsStore.userId === userId && userTermsStore.mediumTerms.length > 0) {
    return userTermsStore.mediumTerms;
  }
  
  // Create a copy of the terms array to avoid modifying the original
  const termsCopy = [...mediumTerms];
  const result: FinancialTerm[] = [];
  
  // Shuffle the array using Fisher-Yates algorithm
  for (let i = termsCopy.length - 1; i > 0; i--) {
    // Use a deterministic seed based on user ID for consistent shuffling
    // This ensures the same user always gets the same set of terms
    const seed = userId.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const j = Math.floor((seed * (i + 1)) % (i + 1));
    [termsCopy[i], termsCopy[j]] = [termsCopy[j], termsCopy[i]];
  }
  
  // Take the first 'count' elements
  for (let i = 0; i < count && i < termsCopy.length; i++) {
    result.push({
      ...termsCopy[i],
      id: `m${i+1}-${userId.substring(0, 5)}` // Generate a unique ID with user prefix
    });
  }
  
  // Store the selected terms for this user
  userTermsStore.userId = userId;
  userTermsStore.mediumTerms = result;
  
  return result;
};

/**
 * Get a subset of the user's medium terms for a specific level
 * @param count Number of terms to select for this level
 * @returns Array of selected financial terms for this level
 */
export const getLevelMediumTerms = (count: number = 5): FinancialTerm[] => {
  // Get the user's full set of terms
  const userTerms = getUserMediumTerms();
  
  // Select a random subset for this level
  const result: FinancialTerm[] = [];
  const indices = new Set<number>();
  
  // Ensure we don't select the same term twice
  while (indices.size < count && indices.size < userTerms.length) {
    const index = Math.floor(Math.random() * userTerms.length);
    if (!indices.has(index)) {
      indices.add(index);
      result.push({
        ...userTerms[index],
        id: `ml${indices.size}-${Math.floor(Math.random() * 1000)}` // Generate a level-specific ID
      });
    }
  }
  
  return result;
};

/**
 * Clear the user's term selection
 * This can be used when the user wants to reset their game
 */
export const clearUserTerms = (): void => {
  userTermsStore.mediumTerms = [];
  localStorage.removeItem('fin_terms_user_id');
  userTermsStore.userId = null;
};