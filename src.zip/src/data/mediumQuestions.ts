import { GameLevel } from '../types/game';
import { mediumTerms } from './mediumTerms';

// Function to get 5 random terms from the mediumTerms array
function getRandomTerms(count: number = 5): GameLevel[] {
  const shuffled = [...mediumTerms].sort(() => 0.5 - Math.random());
  const selected = shuffled.slice(0, count);

  return selected.map((term, index) => ({
    id: index + 1,
    story: term.term, // Using the term itself as the 'story' for definition-based questions
    financialTerms: [{
      id: `mq-${index + 1}`,
      term: term.term,
      hint: term.hint
    }]
  }));
}

// Export the medium level questions
export const mediumQuestions = getRandomTerms();